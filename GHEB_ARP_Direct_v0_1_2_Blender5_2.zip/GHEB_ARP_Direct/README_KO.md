# GHEB ARP Direct 0.1.2 — 설치 및 사용법

이 파일은 제공한 GHEB 1.0.1 ZIP을 수정한 비공식 실험 버전의 설명서다. 현재 캐릭터의 **Unreal 이름을 가진 ARP FBX 골격 → 원래 ARP 리그**를 기준으로 만들고 Blender 5.2에서 검증했다. 기존 설치 애드온과 사용 중인 Blender 장면은 덮어쓰지 않았다.

0.1.1에서는 새 ARP 애드온 자체의 부분 등록을 원본 GHEB 충돌로 잘못 판정하던 문제를 수정했다. 자기 등록 잔여물은 정리하고 다시 활성화하며, 실제 다른 GHEB와의 충돌은 계속 차단한다. 활성화 도중 실패하면 이미 등록한 구성 요소도 정리한다. 이전 버전에서 활성화 오류가 났다면 최신 0.1.2 ZIP으로 교체한다.

0.1.2에서는 활성화 중 발생한 `'_RestrictData' object has no attribute 'scenes'` 오류를 수정했다. 등록 함수에서는 장면을 읽지 않고 등록 이후 타이머에서 초기화한다. 앞선 0.1.1 오류를 Blender의 실제 `addon_utils.enable()` 절차로 재현했으며, 0.1.2는 같은 절차의 활성화·시작 시 등록·부분 등록 복구·저장 파일 읽기 검증을 통과했다. 새 설치에는 0.1.2 ZIP을 사용한다.

업데이트 시 기존 ARP Direct를 제거하고 새 ZIP을 설치한 뒤 Blender를 재시작한다. 이전 실패에서 Python 하위 모듈이 메모리에 남았을 수 있으므로 재시작 후 새 버전을 활성화한다.

## 가장 빠른 시작: 준비한 테스트 파일 사용

1. Blender가 응답 없음 상태라면 먼저 정상 실행 상태로 복구한다. 실행 중인 Blender를 강제로 종료하는 작업은 수행하지 않았다.
2. Blender **Edit → Preferences → Add-ons**에서 기존 **G-HUB Entangle for Blender / GHEB**를 비활성화한다. 두 버전은 같은 패널·속성을 사용하므로 함께 활성화할 수 없다.
3. 애드온 목록의 메뉴에서 **Install from Disk**를 선택하고 `GHEB_ARP_Direct_v0_1_2_Blender5_2.zip`을 설치한다. ZIP을 풀 필요는 없다. **GHEB ARP Direct (experimental)**를 활성화한다. 기존 Auto-Rig Pro 애드온도 활성화해 둔다.
4. `ARP_Cascadeur_Direct_Test.blend`를 연다. 이전에 저장한 바인딩 전 파일을 복제해서 만든 파일이며, 원본 ARP 리그 `rig`와 원래 캐릭터가 들어 있다.
5. 3D View에서 **N → GHEB**를 연다. C1의 **Receiver = ARP Direct: Arms FK / Legs IK**, **Armature = rig**로 설정되어 있다. 프로필도 이미 저장되어 있다. **Imported FBX가 비어 있는 것은 정상**이다. 등록 후 FBX 중계 오브젝트는 이 테스트 파일에서 제거했다.
6. 기존 G-HUB를 실행한다. Blender의 **Control Port**와 Cascadeur GHEC 포트를 같은 값으로 맞춘다. 현재 설정은 `8000`이다.
7. Cascadeur에서 이미 가져온 **같은 FBX 캐릭터**를 연다. GHEC에서 동일한 **C1 / Character 1**을 활성화하고 G-HUB에 CONNECT한다. 다른 캐릭터를 같은 슬롯에 연결하지 않는다.
8. Cascadeur의 **프레임 0을 해당 FBX의 기준 자세**로 유지한다. 기준 자세가 FBX와 다르면 Smart Swizzle이 다른 기준을 잡아 자세가 틀어질 수 있다.
9. Blender에서 **Start Entangle**을 누른다. 처음 연결하면 Smart Swizzle 기준 데이터를 요청한다. **Rest data ready**가 나온 뒤 Cascadeur에서 팔을 조금 움직이거나 프레임을 바꾼다.
10. Blender 상태가 **Live: 61 controls / … ms**가 되고 캐릭터가 따라 움직이는지 확인한다. 처음 시험할 때는 **Body Interpolation OFF**, **Translation Scale 1.0**, **ARP Apply FPS 30**, **Timeline Sync OFF**를 사용한다. 자세 동기화가 확인되면 필요에 따라 Timeline Sync를 켠다.

실행 시 자동으로 연결하지 않는다. 테스트 파일을 열거나 애드온을 활성화한 뒤 사용자가 Start를 눌러야 한다.

## 다른 작업 파일에서 설정하기

현재 파일에 예전 **ARP Remap / Bind Only** 바인딩이 남아 있다면 먼저 ARP Remap에서 해제한다. 이 버전은 그 바인딩이 남은 리그를 거부한다. 준비한 테스트 파일에는 그 바인딩이 없다.

1. 원래 ARP 리그에서 내보낸 **동일한 FBX**를 Blender에 한 번 다시 가져온다. Cascadeur에 넣었던 파일과 동일해야 한다. 본 이름·계층·축·단위가 바뀐 다른 FBX는 사용하지 않는다.
2. GHEB C1의 Receiver를 **ARP Direct**로 바꾼다.
3. **Armature**에는 원래 ARP 리그를 지정한다. 보통 `rig`이며, `c_root_master.x`, `c_arm_fk.l`, `c_foot_ik.l` 등이 있어야 한다.
4. **Imported FBX (capture only)**에는 방금 가져온 FBX의 일반 골격을 지정한다. 현재 캐릭터의 경우 `root`처럼 `pelvis`, `upperarm_l`, `calf_l` 등이 있는 79본 골격이다. ARP 원본이나 Remap 보조 골격을 지정하지 않는다.
5. **Capture FBX → ARP Profile**을 누른다. 현재 캐릭터에서는 **79 FBX bones / 61 ARP controls**가 나온다.
6. `.blend`를 저장한다. 프로필은 `.blend` 안에 저장된다. 필요하면 **Export Profile**로 JSON도 저장할 수 있다.
7. 등록한 뒤에는 가져온 FBX 오브젝트·메시를 제거할 수 있다. 프로필을 새로 등록할 때만 다시 필요하다. 원래 ARP 리그와 원래 스킨 메시를 지우면 안 된다.
8. 위의 연결 순서로 GHEC와 GHEB를 시작한다.

함께 제공한 `ARP_Cascadeur_Direct_Profile.json`은 **현재 캐릭터의 동일한 ARP 기준 골격**에서만 사용할 수 있다. 다른 캐릭터에 그대로 적용하면 기준 골격 검사에서 거부될 수 있다. 다른 캐릭터는 자기 FBX로 Capture를 다시 한다.

## FBX와 실시간 데이터가 처리되는 방식

```text
처음 한 번
원래 ARP 캐릭터 → ARP FBX 내보내기 → Cascadeur에 가져오기
                        └→ Blender에 다시 가져오기 → 프로필 등록

실시간
Cascadeur / GHEC → G-HUB → 수정 GHEB
                         → FBX 자세를 수학적으로 복원
                         → 원래 ARP 컨트롤의 로컬 값으로 변환
                         → ARP의 기존 컨스트레인트·IK·디폼 계산
                         → 캐릭터 메시
```

**매 움직임마다 FBX를 만들지 않는다.** FBX의 본 이름·부모 관계·기준 행렬·단위 변환을 프로필로 저장해 두고, 이후에는 GHEC가 보내는 회전·위치 데이터만 받는다. GHEC와 G-HUB의 통신 형식은 바꾸지 않았다. 원래 Blender GHEB만 이 버전으로 교체한다.

프로필 등록 이후 Blender 장면에 FBX 수신 골격, `ARP_Live_Source`, Remap 보조 본을 둘 필요가 없다. 원래 ARP 컨스트레인트는 계속 평가된다. 이 계산 자체를 없애는 버전은 아니다.

현재 매핑은 다음과 같다.

| Cascadeur / FBX 본 | Blender ARP 컨트롤 | 적용 방식 |
|---|---|---|
| `pelvis` | `c_root_master.x` | 골반 전체 이동·회전 |
| `spine_01`…`spine_05` | `c_spine_01.x`… | FK 회전 |
| `clavicle_l/r` | `c_shoulder.l/r` | FK 회전 |
| `upperarm_l/r` | `c_arm_fk.l/r` | 팔 FK |
| `lowerarm_l/r` | `c_forearm_fk.l/r` | 팔꿈치 FK |
| `hand_l/r` | `c_hand_fk.l/r` | 손목 FK |
| `foot_l/r` | `c_foot_ik.l/r` | 발 위치·회전 |
| `thigh/calf/foot`의 세 관절 | `c_leg_pole.l/r` | 무릎 굽힘 방향 계산 |
| `ball_l/r` | `c_toes_ik.l/r` | 발가락 회전 |
| 목·머리·손가락·손바닥 본 | 대응하는 `c_…` 컨트롤 | 기준 축 보정 후 회전 |

연결 시 팔 FK, 다리 IK, 손가락 FK, 발 폴의 전역 공간을 설정하고 자동 늘어남을 끈다. 무릎이 거의 펴지면 이전 굽힘 방향을 허벅지 좌표계에서 유지해 폴 방향이 갑자기 바뀌는 것을 줄인다. ARP 손바닥 컨트롤의 기존 Copy Rotation 연동도 보정한다.

GHEC에 요청하는 이름은 `pelvis`, `upperarm_l` 같은 **내보낸 FBX 이름**이다. `c_arm_fk.l` 같은 ARP 컨트롤 이름을 Cascadeur에 요구하지 않는다.

## 키 저장과 베이크

- **Apply**는 현재 라이브 자세를 ARP 컨트롤의 키로 기록한다. 골반·발·폴에는 위치 키도 기록한다. IK/FK·폴 공간·자동 늘어남 설정도 키로 남긴다.
- **Offline Body Bake**는 각 GHB 프레임을 같은 ARP 변환기로 계산한 뒤, ARP 컨트롤에 Blender Action을 만든다. FBX 임시 골격의 키를 만드는 방식이 아니다.
- 베이크 중 취소되면 베이크 전 컨트롤 자세를 복구한다. 완료 시 새 Action의 현재 프레임을 평가한다.
- **Stop Entangle**은 수신을 멈추고 마지막 자세를 남긴다. 라이브 동작이 자동으로 전체 애니메이션 키를 남기는 것은 아니다. 전체 애니메이션을 보존하려면 Offline Bake를 사용한다.
- 원래 GHEB의 일반 본 수신 모드는 **Original Bone Receiver**로 남아 있다. 얼굴·타임라인 기능도 기존 코드를 유지했다. 새 버전의 실제 얼굴 송수신은 별도로 검증하지 않았다.

## 상태별 점검

| 상태 | 확인할 것 |
|---|---|
| `Waiting for Cascadeur rest data` | GHEC와 GHEB가 같은 슬롯으로 연결됐는지 확인하고 Smart Swizzle을 실행 |
| `Missing FBX: …` | 해당 본이 Cascadeur 골격에 있는지, FBX가 같은 파일인지, 캐릭터 접두사/슬롯이 맞는지 확인 |
| `Waiting for all required FBX rotations` | Cascadeur에서 자세나 프레임을 변경해 전체 자세가 전송되는지 확인 |
| `Bind Only constraints still exist` | 이전 Remap 바인딩 해제 또는 준비한 테스트 파일 사용 |
| `Reset c_pos and c_traj` | 두 전역 컨트롤의 로컬 변환을 초기화하고 다시 연결 |
| `ARP rest bones differ` | 기준 골격이 달라졌으므로 해당 캐릭터의 FBX로 프로필 재등록 |
| `Constraint prevents direct …` | 표시된 컨트롤의 추가 제약·비표준 설정을 확인. 슬롯이 일시 중지되므로 Stop 후 수정하고 다시 시작 |
| 따라오지만 느림 | Apply FPS를 20 또는 15로 낮추고 Timeline Sync와 Interpolation을 끈 상태에서 비교 |

연결 중 팔 IK/FK나 폴 공간을 수동으로 바꾸면 슬롯을 중지한다. 수정 후 다시 연결한다. 리그 기준 자세, FBX 본 이름·계층·단위 등을 변경했다면 프로필을 다시 등록하고 SS 캐시도 새로 받아야 한다.

## 검증 범위와 한계

현재 캐릭터의 **ARP 366본 / 기존 컨스트레인트 274개**를 사용해 분리된 Blender 5.2 프로세스에서 검증했다. 본·컨스트레인트를 추가하지 않았다. CEU 수신 데이터 변환, 모의 라우트/타이머 처리, 팔 FK, 발 IK, 무릎 방향, 골반 이동·큰 회전, 목·손가락, 키 삽입, 두 프레임 GHB 베이크·재생·취소, 캐시 검사, 기본 본 수신 회귀 등을 확인했다.

**새 애드온을 실제 실행 중인 G-HUB/GHEC와 연결해 장시간 시험한 상태는 아니다.** 사용 중인 Blender가 응답 없음 상태였기 때문에 그 장면을 조작하거나 강제 종료하지 않고 별도 프로세스에서 시험했다. 현재 검증은 모의 패킷을 사용했다. 응답 없음 문제가 해결됐다고 단정할 수 없다.

움직이는 모의 자세 24회의 변환·ARP 평가 시간은 이 환경에서 중앙값 약 **6.4ms**, 최대 약 **18.2ms**였다. 동일한 자세를 반복하면 마지막 측정에서 컨트롤 쓰기는 0회였다. 이는 화면 표시·실제 네트워크·다른 장면 작업을 포함한 성능 수치가 아니며, 이전 Bind Only보다 무조건 빠르다는 의미도 아니다. Apply FPS는 최대 적용 빈도이며 실제 화면 프레임률은 달라질 수 있다.

현재 범위는 **같은 캐릭터를 ARP에서 Unreal 본 이름으로 내보낸 골격**이다. 다른 이름 체계·비표준 ARP 리그·리그 간 체형 보정은 자동 지원하지 않는다. 음수/비균일 FBX 스케일은 거부한다. FK 본의 개별 위치 애니메이션이나 본 스케일·스쿼시/스트레치, 보조 트위스트 본의 독립 애니메이션은 그대로 재현한다고 보장하지 않는다. 방향은 **Cascadeur → Blender**이며, ARP 컨트롤 조작을 Cascadeur로 되돌려 보내는 기능은 추가하지 않았다.

## 출처

원본 GHEB: TeamGadget, 제공한 `GHEB_v1_0_1_Blender5_2LTS.zip`.

공식 프로젝트: https://github.com/TeamGadget-JP/UNIVERSAL_REAL-TIME_SYNC_SYSTEM

본 수정은 TeamGadget의 공식 릴리스나 공식 ARP 지원을 의미하지 않는다. 원본 통신·얼굴·타임라인 코드의 저작권과 배포 조건은 원 저작자에게 남아 있다. Auto-Rig Pro 자체 코드는 포함하지 않았다.
