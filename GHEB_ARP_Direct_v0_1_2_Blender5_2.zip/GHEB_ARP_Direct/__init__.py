bl_info = {
    "name": "GHEB ARP Direct (experimental)",
    "author": "TeamGadget (original), independent ARP modification",
    "version": (0, 1, 2),
    "blender": (5, 2, 0),
    "location": "View3D > Sidebar > GHEB",
    "description": (
        "ARP direct retargeting (FK arms / IK legs), G-HUB live body, "
        "facial, timeline and offline bake synchronization"
    ),
    "category": "Animation",
}

import bpy

from . import GHEB_Timeline
from . import GHEB_ShapeKeys
from . import GHEB_Avatar
from . import GHEB_ARP


_SUPPORTED_BLENDER = (5, 2)


def _require_supported_blender():
    current = tuple(bpy.app.version[:2])
    if current != _SUPPORTED_BLENDER:
        current_text = ".".join(str(v) for v in bpy.app.version)
        raise RuntimeError(
            "GHEB ARP Direct supports Blender 5.2 LTS only. "
            f"Current Blender version: {current_text}"
        )


_REGISTER_ORDER = (GHEB_Timeline, GHEB_ShapeKeys, GHEB_Avatar, GHEB_ARP)
_SCENE_PROPERTIES = ('gheb_props', 'gheb_shape_keys', 'gheb_timeline')


def _registered_class(cls):
    if issubclass(cls, bpy.types.Panel):
        base, identifier = bpy.types.Panel, cls.bl_idname
    elif issubclass(cls, bpy.types.Operator):
        base, identifier = bpy.types.Operator, cls.__name__
    else:
        base, identifier = bpy.types.PropertyGroup, cls.__name__
    return base.bl_rna_get_subclass_py(identifier)


def _registration_owners():
    """Look up actual RNA owners, rather than treating any attribute as a conflict."""
    owners = set()
    classes = []
    for name in _SCENE_PROPERTIES:
        prop = bpy.types.Scene.bl_rna.properties.get(name)
        if prop is not None:
            cls = bpy.types.PropertyGroup.bl_rna_get_subclass_py(prop.fixed_type.identifier)
            if cls is not None:
                owners.add(cls.__module__)
        else:
            # A partially registered PointerProperty may still be deferred.
            deferred = getattr(bpy.types.Scene, name, None)
            cls = getattr(deferred, 'keywords', {}).get('type')
            if cls is not None:
                owners.add(cls.__module__)
    for module in _REGISTER_ORDER:
        for cls in getattr(module, '_CLASSES', getattr(module, 'CLASSES', ())):
            registered = _registered_class(cls)
            if registered is not None:
                owners.add(registered.__module__)
                classes.append(registered)
    return owners, classes


def _cleanup_own_registration(classes):
    # Only our namespace reaches this path. Do not unregister another GHEB.
    for module in reversed(_REGISTER_ORDER):
        try:
            module.unregister()
        except (RuntimeError, ValueError) as exc:
            # An older cached child module may try unregistering a class that
            # never registered. Continue cleaning the other own components.
            print('[GHEB ARP Direct] Partial registration cleanup:', exc)
    for name in _SCENE_PROPERTIES:
        if hasattr(bpy.types.Scene, name):
            delattr(bpy.types.Scene,name)
    for name in dir(bpy.app.handlers):
        handlers=getattr(bpy.app.handlers,name)
        if isinstance(handlers,list):
            for fn in list(handlers):
                if getattr(fn,'__module__','').startswith(__name__+'.'):
                    handlers.remove(fn)
    # After a module reload the current Python class may differ from the RNA
    # class that was originally registered. Remove that precise old class too.
    for cls in reversed(classes):
        if getattr(cls, 'is_registered', False):
            bpy.utils.unregister_class(cls)


def register():
    _require_supported_blender()
    owners, classes = _registration_owners()
    foreign = sorted(owner for owner in owners if not owner.startswith(__name__ + '.'))
    if foreign:
        raise RuntimeError('Another GHEB is registered (' + ', '.join(foreign) +
                           '). Disable it before enabling GHEB ARP Direct.')
    if owners:
        _cleanup_own_registration(classes)
    try:
        for module in _REGISTER_ORDER:
            module.register()
    except Exception:
        # Preserve the original error, and leave a clean state for another try.
        for module in reversed(_REGISTER_ORDER):
            try:
                module.unregister()
            except Exception as cleanup_error:
                print('[GHEB ARP Direct] Registration cleanup:', cleanup_error)
        raise


def unregister():
    for module in reversed(_REGISTER_ORDER):
        module.unregister()
