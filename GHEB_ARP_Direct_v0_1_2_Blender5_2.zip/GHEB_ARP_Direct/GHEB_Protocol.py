# GHEB <-> G-HUB protocol helpers.

PROTOCOL_VERSION = 1
HUB_HOST = "127.0.0.1"
HUB_PORT = 8000

CHARACTER_SLOT_COUNT = 5
CHARACTER_LOCAL_ID = 1
CHARACTER_MATCH_ID = "char_01"

SHAPE_KEY_LOCAL_ID = 1001
SHAPE_KEY_MATCH_ID = "face_01"


def _validate_slot_index(slot_index):
    index = int(slot_index)
    if index < 0 or index >= CHARACTER_SLOT_COUNT:
        raise ValueError(f"Character Slot out of range: {slot_index}")
    return index


def character_local_id(slot_index):
    return _validate_slot_index(slot_index) + 1


def character_match_id(slot_index):
    index = _validate_slot_index(slot_index)
    return f"char_{index + 1:02d}"


def shape_local_id(slot_index):
    return 1001 + _validate_slot_index(slot_index)


def shape_match_id(slot_index):
    index = _validate_slot_index(slot_index)
    return f"face_{index + 1:02d}"


def hello_message():
    # One Blender endpoint advertises every capability implemented by GHEB.
    # Individual channels are registered only when the corresponding UI
    # feature is started.
    return {
        "type": "HELLO",
        "protocol_version": PROTOCOL_VERSION,
        "endpoint_type": "blender",
        "capabilities": [
            "character_transform_receive",
            "shape_key_receive",
            "timeline_send",
            "timeline_receive",
        ],
    }


def channel_add_message(slot_index=0, match_id=None):
    index = _validate_slot_index(slot_index)
    return {
        "type": "CHANNEL_ADD",
        "channel_type": "character_transform_receive",
        "local_id": character_local_id(index),
        "match_id": str(match_id or character_match_id(index)),
    }


def shape_channel_add_message(slot_index=0, match_id=None):
    index = _validate_slot_index(slot_index)
    return {
        "type": "CHANNEL_ADD",
        "channel_type": "shape_key_receive",
        "local_id": shape_local_id(index),
        "match_id": str(match_id or shape_match_id(index)),
    }


def ready_message(channel_id, port):
    return {
        "type": "READY",
        "channel_id": int(channel_id),
        "port": int(port),
    }


def port_fail_message(channel_id, port, reason="bind_failed"):
    return {
        "type": "PORT_FAIL",
        "channel_id": int(channel_id),
        "port": int(port),
        "reason": str(reason),
    }


def relay_message(route_id, payload):
    return {
        "type": "RELAY",
        "route_id": int(route_id),
        "payload": payload,
    }


# ---------------------------------------------------------------------------
# Virtual Timeline
# ---------------------------------------------------------------------------

def timeline_publish_message(time_seconds, is_playing, claim_owner):
    return {
        "type": "TIMELINE_PUBLISH",
        "time_seconds": float(time_seconds),
        "is_playing": bool(is_playing),
        "claim_owner": bool(claim_owner),
    }


def timeline_sync_request_message():
    return {
        "type": "TIMELINE_SYNC_REQUEST",
    }


def timeline_release_message():
    return {
        "type": "TIMELINE_RELEASE",
    }
