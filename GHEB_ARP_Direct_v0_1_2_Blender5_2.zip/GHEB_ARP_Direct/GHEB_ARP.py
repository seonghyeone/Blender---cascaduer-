"""ARP control-space retargeting. No receiver, helper bones, or new constraints.

Original transport: TeamGadget GHEB 1.0.1. This module is an independent
modification, validated first against the user's Unreal-named ARP export.
"""
import hashlib
import json
import math
import time

import bpy
from mathutils import Matrix, Quaternion, Vector

PROFILE_VERSION = 1
IDENTITY = Matrix.Identity(4)
MAX_PROFILE_BYTES = 4 * 1024 * 1024


def _matrix(rows):
    if len(rows) != 4 or any(len(row) != 4 for row in rows):
        raise ValueError('A profile matrix must have four rows and columns.')
    if not all(math.isfinite(float(v)) for row in rows for v in row):
        raise ValueError('Profile contains a non-finite matrix.')
    m = Matrix(rows)
    if abs(m.to_3x3().determinant()) < 1e-12:
        raise ValueError('Profile contains a singular matrix.')
    return m


def _rows(m):
    return [list(row) for row in m]


def target_signature(target, names):
    data = []
    for name in sorted(set(names)):
        bone = target.data.bones.get(name)
        if bone is None:
            raise ValueError('ARP control is missing: ' + name)
        data.append([name, bone.parent.name if bone.parent else '',
                     [round(float(v), 6) for row in bone.matrix_local for v in row]])
    return hashlib.sha256(json.dumps(data, separators=(',', ':')).encode()).hexdigest()


def has_remap_binding(target):
    return bool(target.get('arp_retarget_bound', False)) or any(
        'REMAP' in c.name for pb in target.pose.bones for c in pb.constraints
    )


def default_mapping(source, target):
    """Match Unreal export names to the actual ARP controls, never deform bones."""
    mapping = {'pelvis': 'c_root_master.x', 'head': 'c_head.x',
               'neck_01': 'c_subneck_1.x', 'neck_02': 'c_neck.x'}
    for i in range(1, 20):
        mapping['spine_%02d' % i] = 'c_spine_%02d.x' % i
    for side in ('l', 'r'):
        suffix = '.' + side
        for exported, control in (
            ('clavicle', 'c_shoulder'), ('upperarm', 'c_arm_fk'),
            ('lowerarm', 'c_forearm_fk'), ('hand', 'c_hand_fk'),
            ('foot', 'c_foot_ik'), ('ball', 'c_toes_ik'),
        ):
            mapping[exported + '_' + side] = control + suffix
        for finger in ('thumb', 'index', 'middle', 'ring', 'pinky'):
            for i in range(1, 4):
                mapping['%s_%02d_%s' % (finger, i, side)] = 'c_%s%d%s' % (finger, i, suffix)
            mapping[finger + '_metacarpal_' + side] = 'c_' + finger + '1_base' + suffix
    return {s: t for s, t in mapping.items()
            if s in source.data.bones and t in target.data.bones}


def capture_profile(source, target):
    if source is None or target is None or source.type != 'ARMATURE' or target.type != 'ARMATURE':
        raise ValueError('Choose the exported FBX Armature and the original ARP Armature.')
    if source == target:
        raise ValueError('FBX source and ARP target must be different Armatures.')
    if not all(n in target.data.bones for n in ('c_pos', 'c_traj', 'c_root_master.x')):
        raise ValueError('Target does not contain the expected Auto-Rig Pro controllers.')
    if has_remap_binding(target):
        raise ValueError('Unbind the previous ARP Remap / Bind Only connection first.')
    if any('arp_remap_temp_bone' in b for b in source.data.bones):
        raise ValueError('Choose the clean FBX Armature, not an ARP Remap helper skeleton.')
    mapping = default_mapping(source, target)
    essential = ('pelvis', 'upperarm_l', 'lowerarm_l', 'hand_l', 'upperarm_r',
                 'lowerarm_r', 'hand_r', 'foot_l', 'foot_r')
    missing = [n for n in essential if n not in mapping]
    if missing:
        raise ValueError('This Unreal/ARP profile cannot map: ' + ', '.join(missing))
    # Object placement is presentation. Capture only import rotation and units;
    # do not transfer the user's side-by-side FBX object translation.
    conversion = (target.matrix_world.to_3x3().inverted() @ source.matrix_world.to_3x3()).to_4x4()
    scales = conversion.to_scale()
    if conversion.to_3x3().determinant()<=0 or min(scales) <= 0 or max(scales) / min(scales) > 1.0001:
        raise ValueError('FBX source needs a positive, uniform object scale.')
    nodes = []
    for bone in source.data.bones:
        if not bone.use_inherit_rotation or bone.inherit_scale != 'FULL':
            raise ValueError('Unsupported FBX inheritance on ' + bone.name)
        nodes.append({'name': bone.name, 'parent': bone.parent.name if bone.parent else '',
                      'rest': _rows(bone.matrix_local)})
    controls = []
    for sn, tn in mapping.items():
        controls.append({'source': sn, 'target': tn,
                         'kind': 'ROOT' if sn == 'pelvis' else 'IK' if sn.startswith('foot_') else 'FK',
                         'rest': _rows(target.data.bones[tn].matrix_local)})
    legs = []
    for side in ('l', 'r'):
        names = ['thigh_' + side, 'calf_' + side, 'foot_' + side]
        pole = 'c_leg_pole.' + side
        if any(n not in source.data.bones for n in names) or pole not in target.data.bones:
            raise ValueError('Missing leg chain / pole for side ' + side)
        h, k, a = [conversion @ source.data.bones[n].head_local for n in names]
        rest_pole = target.data.bones[pole].head_local.copy()
        chain = a - h
        projection = h + chain * ((k - h).dot(chain) / max(chain.length_squared, 1e-12))
        direction = k - projection
        if direction.length < 1e-6:
            direction = rest_pole - projection
            direction -= chain * (direction.dot(chain) / max(chain.length_squared, 1e-12))
        if direction.length < 1e-6:
            raise ValueError('Cannot determine the rest knee pole direction: ' + side)
        legs.append({'side': side, 'hip': names[0], 'knee': names[1], 'ankle': names[2],
                     'pole': pole, 'rest': _rows(target.data.bones[pole].matrix_local),
                     'direction': list(direction.normalized()),
                     'distance': max((rest_pole - k).length, (k-h).length + (a-k).length)})
    names = [c['target'] for c in controls] + [l['pole'] for l in legs]
    payload = {'version': PROFILE_VERSION, 'preset': 'Unreal export -> ARP (arms FK / legs IK)',
               'source_name': source.name, 'source_conversion': _rows(conversion),
               'source_bones': nodes, 'controls': controls, 'legs': legs,
               'target_signature': target_signature(target, names)}
    payload['fingerprint'] = hashlib.sha256(
        json.dumps(payload, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
    validate_profile(payload, target)
    return payload


def parse_profile(raw, target):
    if not raw or len(raw.encode('utf-8')) > MAX_PROFILE_BYTES:
        raise ValueError('ARP profile is missing or too large.')
    profile = json.loads(raw)
    validate_profile(profile, target)
    return profile


def validate_profile(profile, target):
    if profile.get('version') != PROFILE_VERSION:
        raise ValueError('Unsupported ARP profile version.')
    nodes = profile.get('source_bones', [])
    controls = profile.get('controls', [])
    if not nodes or len(nodes) > 2048 or not controls or len(controls) > 1024:
        raise ValueError('Invalid source / target bone counts.')
    _matrix(profile['source_conversion'])
    by_name = {n['name']: n for n in nodes}
    if len(by_name) != len(nodes):
        raise ValueError('Duplicate source bone names.')
    for n in nodes:
        _matrix(n['rest'])
        seen = {n['name']}
        parent = n['parent']
        while parent:
            if parent not in by_name or parent in seen:
                raise ValueError('Missing parent or cyclic FBX hierarchy.')
            seen.add(parent)
            parent = by_name[parent]['parent']
    targets = []
    roots = []
    for c in controls:
        if c['source'] not in by_name or c['kind'] not in ('ROOT', 'FK', 'IK'):
            raise ValueError('Invalid control mapping.')
        _matrix(c['rest'])
        targets.append(c['target'])
        if c['kind'] == 'ROOT':
            roots.append(c)
    if len(targets) != len(set(targets)) or len(roots) != 1:
        raise ValueError('Each control needs one source, and exactly one root mapping.')
    if len(profile.get('legs', [])) != 2:
        raise ValueError('Profile must contain both leg poles.')
    if {leg['side'] for leg in profile['legs']}!={'l','r'}:
        raise ValueError('Profile needs one left and one right pole.')
    for leg in profile['legs']:
        if any(leg[k] not in by_name for k in ('hip', 'knee', 'ankle')):
            raise ValueError('Invalid leg source chain.')
        _matrix(leg['rest'])
        if not math.isfinite(leg['distance']) or leg['distance'] <= 0:
            raise ValueError('Invalid pole distance.')
        if len(leg['direction']) != 3 or not all(math.isfinite(v) for v in leg['direction']) or Vector(leg['direction']).length<1e-6:
            raise ValueError('Invalid pole direction.')
        targets.append(leg['pole'])
    if len(targets)!=len(set(targets)):
        raise ValueError('Pole and main controllers must be distinct.')
    if target is None or target.type != 'ARMATURE':
        raise ValueError('ARP target Armature is missing.')
    if target_signature(target, targets) != profile['target_signature']:
        raise ValueError('ARP rest bones differ from the captured profile. Capture a new profile.')
    payload = dict(profile)
    fingerprint = payload.pop('fingerprint', '')
    actual = hashlib.sha256(json.dumps(payload, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
    if fingerprint != actual:
        raise ValueError('Profile fingerprint mismatch; capture or export a new profile.')


def check_target(target):
    if has_remap_binding(target):
        raise ValueError('Bind Only constraints still exist. Unbind them before ARP Direct.')
    for name in ('c_pos','c_traj'):
        pb=target.pose.bones.get(name)
        if pb is None or max(abs(pb.matrix_basis[i][j]-IDENTITY[i][j]) for i in range(4) for j in range(4))>1e-5:
            raise ValueError('Reset c_pos and c_traj transforms before using ARP Direct.')


def prepare_target(target):
    check_target(target)
    # These switches drive the original rig's own constraints, not new ones.
    for side in ('l', 'r'):
        for name, switch in (('c_hand_ik.'+side, 1.0), ('c_foot_ik.'+side, 0.0)):
            pb = target.pose.bones[name]
            pb['ik_fk_switch'] = switch
            if 'auto_stretch' in pb:
                pb['auto_stretch'] = 0.0
        pole = target.pose.bones['c_leg_pole.'+side]
        if 'pole_parent' in pole:
            pole['pole_parent'] = 0
    for pb in target.pose.bones:
        if any(pb.name.startswith('c_'+f) for f in ('thumb','index','middle','ring','pinky')):
            if 'ik_fk_switch' in pb:
                pb['ik_fk_switch'] = 1.0
    bpy.context.view_layer.update()


class ARPDirectEngine:
    def __init__(self, profile, target):
        validate_profile(profile, target)
        if has_remap_binding(target):
            raise ValueError('ARP target is still bound with ARP Remap.')
        self.profile = profile
        self.target = target
        self.conversion = _matrix(profile['source_conversion'])
        self.nodes = {n['name']: n for n in profile['source_bones']}
        self.rest = {name: _matrix(n['rest']) for name,n in self.nodes.items()}
        self.local_rest = {name: (self.rest[n['parent']].inverted() @ self.rest[name]
                                 if n['parent'] else self.rest[name].copy()) for name,n in self.nodes.items()}
        self.depth = {}
        def depth(name):
            if name not in self.depth:
                parent = self.nodes[name]['parent']
                self.depth[name] = depth(parent)+1 if parent else 0
            return self.depth[name]
        self.order = sorted(self.nodes, key=depth)
        self.groups = {}
        self.required_sources = set()
        for c in profile['controls']:
            item = dict(c)
            item['offset'] = (self.conversion @ self.rest[c['source']]).inverted() @ _matrix(c['rest'])
            self.groups.setdefault(self.depth[c['source']], []).append(item)
            self.required_sources.add(c['source'])
        for leg in profile['legs']:
            self.required_sources.update(leg[k] for k in ('hip','knee','ankle'))
        for name in list(self.required_sources):
            p = self.nodes[name]['parent']
            while p:
                self.required_sources.add(p)
                p = self.nodes[p]['parent']
        self.control_names = [c['target'] for c in profile['controls']] + [l['pole'] for l in profile['legs']]
        self.location_controls = {c['target'] for c in profile['controls'] if c['kind'] in ('ROOT','IK')}
        self.location_controls.update(l['pole'] for l in profile['legs'])
        self.last_poles = {}
        self.last_eval_ms = 0.0
        self.last_changed = 0
        self.output_bindings = {i:(target.name,n) for i,n in enumerate(self.control_names)}

    def reconstruct(self, samples):
        poses = {}
        for name in self.order:
            values = samples.get(name, {})
            q = values.get('rot', Quaternion((1,0,0,0)))
            p = values.get('loc', Vector((0,0,0)))
            if not all(math.isfinite(v) for v in (*q, *p)) or q.magnitude < 1e-8:
                raise ValueError('Invalid received transform: ' + name)
            local = self.local_rest[name] @ Matrix.LocRotScale(p, q.normalized(), Vector((1,1,1)))
            parent = self.nodes[name]['parent']
            poses[name] = poses[parent] @ local if parent else local
        return {name: self.conversion @ m for name,m in poses.items()}

    def _write(self, name, desired, location=False):
        pb = self.target.pose.bones[name]
        current = pb.matrix
        q = desired.to_quaternion().normalized()
        old_q = current.to_quaternion().normalized()
        delta=old_q.rotation_difference(q)
        needs_rotation = delta.x*delta.x+delta.y*delta.y+delta.z*delta.z > 1e-10
        needs_location = location and (current.translation-desired.translation).length > 2e-6
        if not needs_rotation and not needs_location:
            return False
        final = Matrix.LocRotScale(desired.translation if location else current.translation,
                                   q, current.to_scale())
        args = {}
        if pb.parent:
            args = {'parent_matrix':pb.parent.matrix,
                    'parent_matrix_local':pb.parent.bone.matrix_local}
        basis = pb.bone.convert_local_to_pose(final, pb.bone.matrix_local, invert=True, **args)
        pb.rotation_mode = 'QUATERNION'
        local_q = basis.to_quaternion().normalized()
        # The hand cup controls already have ARP Copy Rotation OFFSET links.
        # Recover their evaluated local offset instead of deleting/muting them.
        # A bounded correction pass below handles legacy Euler OFFSET mixing.
        if any(not co.mute and co.influence>1e-7 for co in pb.constraints):
            evaluated=pb.bone.convert_local_to_pose(current,pb.bone.matrix_local,invert=True,**args)
            own=pb.matrix_basis.to_quaternion().normalized()
            offset=own.inverted() @ evaluated.to_quaternion().normalized()
            local_q=local_q @ offset.inverted()
        if pb.rotation_quaternion.dot(local_q) < 0:
            local_q.negate()
        pb.rotation_quaternion = local_q
        if location:
            pb.location = basis.translation
        return True

    def apply(self, samples, pole_epsilon=0.002):
        start = time.perf_counter()
        for name in ('c_pos','c_traj'):
            basis=self.target.pose.bones[name].matrix_basis
            if max(abs(basis[i][j]-IDENTITY[i][j]) for i in range(4) for j in range(4))>1e-5:
                raise ValueError('c_pos / c_traj changed. Stop, reset them and reconnect.')
        for side in ('l','r'):
            if (self.target.pose.bones['c_hand_ik.'+side]['ik_fk_switch']!=1
                    or self.target.pose.bones['c_foot_ik.'+side]['ik_fk_switch']!=0
                    or self.target.pose.bones['c_leg_pole.'+side].get('pole_parent',0)!=0):
                raise ValueError('ARP IK/FK or pole space changed. Stop and reconnect.')
        poses = self.reconstruct(samples)
        changed = 0
        # Batched source-depth stages ensure ARP's own constrained parent bones
        # are current before converting descendants into local control space.
        # The receiver invokes this only from the main timer, never inside
        # frame_change_post / dependency-graph evaluation callbacks.
        for depth in sorted(self.groups):
            dirty = False
            constrained=[]
            for c in self.groups[depth]:
                desired = poses[c['source']] @ c['offset']
                if c['kind']=='ROOT':
                    desired.translation = poses[c['source']].translation + (
                        _matrix(c['rest']).translation -
                        (self.conversion @ self.rest[c['source']]).translation)
                wrote = self._write(c['target'], desired, c['kind'] in ('ROOT','IK'))
                if any(not co.mute and co.influence>1e-7 for co in self.target.pose.bones[c['target']].constraints):
                    constrained.append((c,desired))
                dirty |= wrote
                changed += int(wrote)
            if dirty:
                bpy.context.view_layer.update()
            for _ in range(4):
                corrected=False
                for c,desired in constrained:
                    wrote=self._write(c['target'],desired,c['kind'] in ('ROOT','IK'))
                    corrected|=wrote
                    changed+=int(wrote)
                if not corrected:break
                bpy.context.view_layer.update()
        pole_dirty = False
        for leg in self.profile['legs']:
            h,k,a = [poses[leg[n]].translation for n in ('hip','knee','ankle')]
            chain=a-h
            length=chain.length
            projected=h+chain*((k-h).dot(chain)/max(chain.length_squared,1e-12))
            normal=k-projected
            hip_delta=(poses[leg['hip']] @ (self.conversion @ self.rest[leg['hip']]).inverted()).to_quaternion()
            threshold=max(1e-6, float(pole_epsilon)*((k-h).length+(a-k).length))
            if normal.length < threshold or length < 1e-6:
                normal=hip_delta @ self.last_poles.get(leg['side'],Vector(leg['direction']))
                normal-=chain*(normal.dot(chain)/max(chain.length_squared,1e-12))
            if normal.length < 1e-6:
                normal=hip_delta @ Vector(leg['direction'])
                normal-=chain*(normal.dot(chain)/max(chain.length_squared,1e-12))
            if normal.length < 1e-6:
                seed=min((Vector((1,0,0)),Vector((0,1,0)),Vector((0,0,1))),key=lambda v:abs(v.dot(chain)))
                normal=seed-chain*(seed.dot(chain)/max(chain.length_squared,1e-12))
            normal.normalize()
            self.last_poles[leg['side']]=hip_delta.inverted() @ normal
            desired=self.target.pose.bones[leg['pole']].matrix.copy()
            desired.translation=k+normal*leg['distance']
            wrote=self._write(leg['pole'],desired,True)
            pole_dirty |= wrote
            changed+=int(wrote)
        if pole_dirty:
            bpy.context.view_layer.update()
        # A custom rig constraint can prevent the requested control pose.
        # Pause with a concrete diagnostic instead of silently claiming sync.
        for group in self.groups.values():
            for c in group:
                desired=poses[c['source']] @ c['offset']
                if c['kind']=='ROOT':
                    desired.translation=poses[c['source']].translation+(_matrix(c['rest']).translation-(self.conversion@self.rest[c['source']]).translation)
                actual=self.target.pose.bones[c['target']].matrix
                dq=actual.to_quaternion().rotation_difference(desired.to_quaternion())
                if dq.x*dq.x+dq.y*dq.y+dq.z*dq.z>1e-6:
                    raise ValueError('Constraint prevents direct rotation: '+c['target'])
                if c['kind'] in ('ROOT','IK') and (actual.translation-desired.translation).length>1e-4:
                    raise ValueError('Constraint prevents direct position: '+c['target'])
        self.last_eval_ms=(time.perf_counter()-start)*1000.0
        self.last_changed=changed
        return self.channels()

    def channels(self):
        output={}
        for i,(_,name) in self.output_bindings.items():
            pb=self.target.pose.bones[name]
            q=pb.rotation_quaternion.copy() if pb.rotation_mode=='QUATERNION' else pb.matrix_basis.to_quaternion()
            row={'rot':q}
            if name in self.location_controls:
                row['loc']=pb.location.copy()
            output[i]=row
        return output

    def key_current(self, frame):
        count=0
        for name in self.control_names:
            pb=self.target.pose.bones[name]
            if pb.rotation_mode!='QUATERNION':
                pb.rotation_quaternion=pb.matrix_basis.to_quaternion()
                pb.rotation_mode='QUATERNION'
            count+=int(pb.keyframe_insert(data_path='rotation_quaternion',frame=frame))
            if name in self.location_controls:
                count+=int(pb.keyframe_insert(data_path='location',frame=frame))
        for name,key,value in mode_channels(self.target):
            pb=self.target.pose.bones[name]
            pb[key]=value
            pb.keyframe_insert(data_path='["%s"]'%key,frame=frame)
        return count


def mode_channels(target):
    rows=[]
    for side in ('l','r'):
        rows.extend([('c_hand_ik.'+side,'ik_fk_switch',1.0),
                     ('c_foot_ik.'+side,'ik_fk_switch',0.0),
                     ('c_leg_pole.'+side,'pole_parent',0)])
        for name in ('c_hand_ik.'+side,'c_foot_ik.'+side):
            if 'auto_stretch' in target.pose.bones[name]:
                rows.append((name,'auto_stretch',0.0))
    for pb in target.pose.bones:
        if any(pb.name.startswith('c_'+f) for f in ('thumb','index','middle','ring','pinky')) and 'ik_fk_switch' in pb:
            rows.append((pb.name,'ik_fk_switch',1.0))
    return rows


class GHEB_OT_ARPCapture(bpy.types.Operator):
    bl_idname='gheb.arp_capture'
    bl_label='Capture FBX -> ARP Profile'
    bl_description='Store FBX hierarchy, units and rest offsets; no new bones or constraints'
    bl_options={'REGISTER','UNDO'}
    slot_index:bpy.props.IntProperty()
    def execute(self,context):
        if context.scene.gheb_props.is_running:
            self.report({'ERROR'},'Stop Entangle before changing the ARP profile.')
            return {'CANCELLED'}
        slot=context.scene.gheb_props.slots[self.slot_index]
        try:
            profile=capture_profile(slot.arp_source,slot.target_armature)
            slot.arp_profile_json=json.dumps(profile,separators=(',',':'))
            slot.has_ss_data=False;slot.ss_data_json='';slot.ss_cache_version=0
            slot.arp_ss_fingerprint=''
            slot.arp_status='%d FBX bones / %d ARP controls'%(len(profile['source_bones']),len(profile['controls'])+2)
            self.report({'INFO'},'Profile captured. FBX object is no longer needed for live reception.')
            return {'FINISHED'}
        except Exception as exc:
            self.report({'ERROR'},str(exc))
            return {'CANCELLED'}


class GHEB_OT_ARPExport(bpy.types.Operator):
    bl_idname='gheb.arp_export_profile'
    bl_label='Export ARP Profile'
    slot_index:bpy.props.IntProperty()
    filepath:bpy.props.StringProperty(subtype='FILE_PATH')
    filter_glob:bpy.props.StringProperty(default='*.json',options={'HIDDEN'})
    def invoke(self,context,event):
        self.filepath='GHEB_ARP_profile.json'
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}
    def execute(self,context):
        slot=context.scene.gheb_props.slots[self.slot_index]
        try:
            profile=parse_profile(slot.arp_profile_json,slot.target_armature)
            path=self.filepath if self.filepath.lower().endswith('.json') else self.filepath+'.json'
            with open(path,'w',encoding='utf-8') as f:json.dump(profile,f,ensure_ascii=False,indent=2)
            return {'FINISHED'}
        except Exception as exc:
            self.report({'ERROR'},str(exc));return {'CANCELLED'}


class GHEB_OT_ARPImport(bpy.types.Operator):
    bl_idname='gheb.arp_import_profile'
    bl_label='Import ARP Profile'
    bl_options={'REGISTER','UNDO'}
    slot_index:bpy.props.IntProperty()
    filepath:bpy.props.StringProperty(subtype='FILE_PATH')
    filter_glob:bpy.props.StringProperty(default='*.json',options={'HIDDEN'})
    def invoke(self,context,event):
        context.window_manager.fileselect_add(self);return {'RUNNING_MODAL'}
    def execute(self,context):
        if context.scene.gheb_props.is_running:
            self.report({'ERROR'},'Stop Entangle before changing the profile.');return {'CANCELLED'}
        slot=context.scene.gheb_props.slots[self.slot_index]
        try:
            with open(self.filepath,encoding='utf-8-sig') as f:raw=f.read(MAX_PROFILE_BYTES+1)
            profile=parse_profile(raw,slot.target_armature)
            slot.arp_profile_json=json.dumps(profile,separators=(',',':'))
            slot.has_ss_data=False;slot.ss_data_json='';slot.ss_cache_version=0;slot.arp_ss_fingerprint=''
            slot.arp_status='%d FBX bones / %d ARP controls'%(len(profile['source_bones']),len(profile['controls'])+2)
            return {'FINISHED'}
        except Exception as exc:
            self.report({'ERROR'},str(exc));return {'CANCELLED'}


CLASSES=(GHEB_OT_ARPCapture,GHEB_OT_ARPExport,GHEB_OT_ARPImport)

def register():
    for cls in CLASSES:bpy.utils.register_class(cls)

def unregister():
    for cls in reversed(CLASSES):
        if getattr(cls, 'is_registered', False):
            bpy.utils.unregister_class(cls)
