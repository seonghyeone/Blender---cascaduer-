import bpy
from bpy.app.handlers import persistent


# Shape receivers and caches are isolated per Character Slot so different
# characters may safely use identical Shape Key names.
_shape_caches = {}
_VALUE_EPSILON = 1.0e-4
_SHAPE_SLOT_COUNT = 5


class GHEBShapeSlotProps(bpy.types.PropertyGroup):
    is_active: bpy.props.BoolProperty(name="Active", default=False)
    target_mesh: bpy.props.PointerProperty(
        name="Target",
        type=bpy.types.Object,
        poll=lambda self, obj: obj.type == 'MESH',
    )

    hub_status: bpy.props.StringProperty(default="OFF", options={'SKIP_SAVE'})
    channel_id: bpy.props.IntProperty(default=0, options={'SKIP_SAVE'})
    route_id: bpy.props.IntProperty(default=0, options={'SKIP_SAVE'})
    udp_port: bpy.props.IntProperty(default=0, options={'SKIP_SAVE'})
    udp_packets: bpy.props.IntProperty(default=0, options={'SKIP_SAVE'})


class GHEBShapeKeyProps(bpy.types.PropertyGroup):
    # Compatibility field retained for .blend files created before
    # per-Character Shape targets were introduced.
    target_mesh: bpy.props.PointerProperty(
        name="Legacy Target",
        type=bpy.types.Object,
        poll=lambda self, obj: obj.type == 'MESH',
    )

    slots: bpy.props.CollectionProperty(type=GHEBShapeSlotProps)

    is_running: bpy.props.BoolProperty(default=False, options={'SKIP_SAVE'})
    hub_status: bpy.props.StringProperty(default="OFF", options={'SKIP_SAVE'})
    channel_id: bpy.props.IntProperty(default=0, options={'SKIP_SAVE'})
    route_id: bpy.props.IntProperty(default=0, options={'SKIP_SAVE'})
    udp_port: bpy.props.IntProperty(default=0, options={'SKIP_SAVE'})
    udp_packets: bpy.props.IntProperty(default=0, options={'SKIP_SAVE'})


def init_shape_slots(scene):
    if scene is None or not hasattr(scene, "gheb_shape_keys"):
        return

    props = scene.gheb_shape_keys
    while len(props.slots) < _SHAPE_SLOT_COUNT:
        index = len(props.slots)
        slot = props.slots.add()
        slot.is_active = (index == 0)

    # Migrate the former single Target into Character 1 exactly once when the
    # new Slot 0 has no target yet.
    if props.target_mesh is not None and props.slots[0].target_mesh is None:
        props.slots[0].target_mesh = props.target_mesh


def get_shape_slot(scene, slot_index):
    if scene is None or not hasattr(scene, "gheb_shape_keys"):
        return None
    try:
        index = int(slot_index)
    except Exception:
        return None
    props = scene.gheb_shape_keys
    if index < 0 or index >= len(props.slots):
        return None
    return props.slots[index]


def get_shape_target(scene, slot_index=0):
    slot = get_shape_slot(scene, slot_index)
    return getattr(slot, "target_mesh", None) if slot is not None else None


def configured_shape_slots(scene):
    if scene is None or not hasattr(scene, "gheb_shape_keys"):
        return []
    result = []
    for index, slot in enumerate(scene.gheb_shape_keys.slots):
        if index >= _SHAPE_SLOT_COUNT:
            break
        if slot.is_active and slot.target_mesh is not None:
            result.append(index)
    return result


def _shape_signature(obj):
    if not obj or obj.type != 'MESH' or not obj.data.shape_keys:
        return None
    return tuple(kb.name for kb in obj.data.shape_keys.key_blocks)


def _cache_key(slot_index):
    return int(slot_index)


def _find_character_armature(obj):
    if obj is None:
        return None
    try:
        return obj.find_armature()
    except Exception:
        return None


def _discover_character_shape_meshes(scene, slot_index=0):
    """Return Shape Key meshes belonging to the same character as Target."""
    index = int(slot_index)
    target = get_shape_target(scene, index)
    if (
        target is None
        or target.type != 'MESH'
        or target.data.shape_keys is None
    ):
        return []

    armature = _find_character_armature(target)
    if armature is None or scene is None:
        return [target]

    result = []
    for obj in scene.objects:
        if (
            obj is None
            or obj.type != 'MESH'
            or obj.data is None
            or obj.data.shape_keys is None
        ):
            continue

        if _find_character_armature(obj) == armature:
            result.append(obj)

    if target not in result:
        result.append(target)

    result.sort(key=lambda obj: obj.name)
    return result


def _add_alias_binding(aliases, alias_name, key_block):
    alias = str(alias_name or "")
    if not alias or key_block is None:
        return

    bindings = aliases.setdefault(alias, [])
    for existing in bindings:
        if existing == key_block:
            return
    bindings.append(key_block)


def rebuild_shape_cache(scene=None, slot_index=0):
    scene = scene or getattr(bpy.context, "scene", None)
    index = int(slot_index)
    target = get_shape_target(scene, index)
    target_signature = _shape_signature(target)
    if target is None or target_signature is None:
        _shape_caches.pop(_cache_key(index), None)
        return 0

    meshes = _discover_character_shape_meshes(scene, index)
    aliases = {}
    concrete_count = 0

    for obj in meshes:
        shape_keys = getattr(obj.data, "shape_keys", None)
        if shape_keys is None:
            continue

        for kb in shape_keys.key_blocks:
            if kb.name == "Basis":
                continue

            concrete_count += 1
            _add_alias_binding(aliases, kb.name, kb)

            if "." in kb.name:
                short_name = kb.name.rsplit(".", 1)[-1]
                _add_alias_binding(aliases, short_name, kb)

    armature = _find_character_armature(target)
    _shape_caches[_cache_key(index)] = {
        "object_name": target.name,
        "signature": target_signature,
        "armature_name": armature.name if armature is not None else "",
        "mesh_names": tuple(obj.name for obj in meshes),
        "aliases": aliases,
        "concrete_count": concrete_count,
    }

    print(
        f"[GHEB ShapeKeys] Slot {index} cache / "
        f"{len(meshes)} mesh(es) / "
        f"{concrete_count} concrete Shape Key(s) / "
        f"{len(aliases)} live alias(es)"
    )
    return len(aliases)


def _ensure_shape_cache(scene, slot_index=0):
    index = int(slot_index)
    obj = get_shape_target(scene, index)
    signature = _shape_signature(obj)
    cache = _shape_caches.get(_cache_key(index))
    if (
        obj is None
        or signature is None
        or cache is None
        or obj.name != cache.get("object_name")
        or signature != cache.get("signature")
    ):
        rebuild_shape_cache(scene, index)


def resolve_shape_bindings(scene, shape_name, slot_index=0):
    """Resolve one ShapeMixer name to all concrete KeyBlocks in the Character.

    Returns tuples of:
        (mesh_object, shape_key_datablock, key_block)

    Exact raw names and suffix aliases use the same cache as live sync, so
    Offline Facial Bake and live facial synchronization share one resolution
    contract.
    """
    index = int(slot_index)
    target = get_shape_target(scene, index)
    if not target or target.type != 'MESH' or not target.data.shape_keys:
        return []

    _ensure_shape_cache(scene, index)
    cache = _shape_caches.get(_cache_key(index), {})
    key_blocks = cache.get("aliases", {}).get(str(shape_name), ())
    if not key_blocks:
        return []

    meshes = _discover_character_shape_meshes(scene, index)
    result = []
    seen = set()

    for kb in key_blocks:
        try:
            key_data = kb.id_data
        except Exception:
            continue

        owner = None
        for obj in meshes:
            try:
                if obj.data.shape_keys == key_data:
                    owner = obj
                    break
            except Exception:
                continue

        if owner is None:
            continue

        try:
            concrete_key = (int(key_data.as_pointer()), str(kb.name))
        except Exception:
            concrete_key = (owner.name, str(kb.name))

        if concrete_key in seen:
            continue
        seen.add(concrete_key)
        result.append((owner, key_data, kb))

    return result


def has_shape_binding(scene, shape_name, slot_index=0):
    """Return True when an incoming ShapeMixer name resolves anywhere in Character."""
    return bool(resolve_shape_bindings(scene, shape_name, slot_index))


def apply_live_updates(scene, updates, slot_index=0):
    """Apply ShapeMixer values to every matching Shape Key mesh in one Slot."""
    index = int(slot_index)
    obj = get_shape_target(scene, index)
    if not obj or obj.type != 'MESH' or not obj.data.shape_keys:
        return 0

    _ensure_shape_cache(scene, index)
    cache = _shape_caches.get(_cache_key(index), {})
    aliases = cache.get("aliases", {})

    applied = 0
    for shape_name, weight in updates.items():
        bindings = aliases.get(str(shape_name), ())
        if not bindings:
            continue

        value = max(0.0, min(1.0, float(weight) / 100.0))

        for kb in bindings:
            try:
                if abs(float(kb.value) - value) <= _VALUE_EPSILON:
                    continue
                kb.value = value
                applied += 1
            except ReferenceError:
                continue

    return applied


def has_local_shape_animation(scene, slot_index=0):
    """Return True if any participating character mesh has local Shape animation."""
    for obj in _discover_character_shape_meshes(scene, slot_index):
        shape_keys = getattr(obj.data, "shape_keys", None)
        if shape_keys is None:
            continue

        animation_data = shape_keys.animation_data
        if animation_data is None:
            continue

        if animation_data.action is not None:
            return True

        try:
            if any(not track.mute for track in animation_data.nla_tracks):
                return True
        except Exception:
            pass

    return False


class GHEB_OT_StartShapeSync(bpy.types.Operator):
    bl_idname = "gheb.start_shape_sync"
    bl_label = "Start ShapeMixer Sync"

    def execute(self, context):
        scene = context.scene
        props = scene.gheb_shape_keys
        init_shape_slots(scene)

        active_slots = []
        missing_targets = []
        invalid_targets = []
        for index, slot in enumerate(props.slots):
            if index >= _SHAPE_SLOT_COUNT:
                break
            if not slot.is_active:
                continue
            active_slots.append(index)
            if slot.target_mesh is None:
                missing_targets.append(index)
            elif not slot.target_mesh.data.shape_keys:
                invalid_targets.append(index)

        if not active_slots:
            self.report({'WARNING'}, "Enable at least one Shape Slot.")
            return {'CANCELLED'}
        if missing_targets:
            labels = ", ".join(f"C{i + 1}" for i in missing_targets)
            self.report({'WARNING'}, f"Active Shape Slot has no Target: {labels}")
            return {'CANCELLED'}
        if invalid_targets:
            labels = ", ".join(f"C{i + 1}" for i in invalid_targets)
            self.report({'WARNING'}, f"Target Mesh has no Shape Keys: {labels}")
            return {'CANCELLED'}

        for index in active_slots:
            rebuild_shape_cache(scene, index)
            props.slots[index].udp_packets = 0

        # Keep the former single-target field aligned with Character 1 so the
        # existing Slot-0 Shape Bake path remains backward compatible.
        props.target_mesh = props.slots[0].target_mesh

        from . import GHEB_Avatar
        if not GHEB_Avatar.start_shape_sync(scene):
            self.report({'ERROR'}, "Failed to start ShapeMixer sync.")
            return {'CANCELLED'}

        props.is_running = True
        self.report({'INFO'}, f"ShapeMixer sync started ({len(active_slots)} Slot(s)).")
        return {'FINISHED'}


class GHEB_OT_StopShapeSync(bpy.types.Operator):
    bl_idname = "gheb.stop_shape_sync"
    bl_label = "Stop ShapeMixer Sync"

    def execute(self, context):
        from . import GHEB_Avatar
        GHEB_Avatar.stop_shape_sync(context.scene)
        context.scene.gheb_shape_keys.is_running = False
        self.report({'INFO'}, "ShapeMixer sync stopped.")
        return {'FINISHED'}


class GHEB_OT_ResetShapeKeys(bpy.types.Operator):
    bl_idname = "gheb.reset_shape_keys"
    bl_label = "Blend Shape All Reset"
    bl_description = "Reset Shape Keys on all participating meshes of enabled Shape Slots to 0.0"

    def execute(self, context):
        scene = context.scene
        init_shape_slots(scene)

        reset_meshes = 0
        seen_mesh_names = set()

        for index, slot in enumerate(scene.gheb_shape_keys.slots):
            if index >= _SHAPE_SLOT_COUNT:
                break
            if not slot.is_active:
                continue

            for obj in _discover_character_shape_meshes(scene, index):
                if obj.name in seen_mesh_names:
                    continue
                seen_mesh_names.add(obj.name)

                shape_keys = getattr(obj.data, "shape_keys", None)
                if shape_keys is None:
                    continue

                for key_block in shape_keys.key_blocks:
                    if key_block.name != "Basis":
                        key_block.value = 0.0
                reset_meshes += 1

        if reset_meshes == 0:
            self.report(
                {'WARNING'},
                "No enabled Shape Slot has a valid Shape Key mesh.",
            )
            return {'CANCELLED'}

        self.report(
            {'INFO'},
            f"Blend Shapes reset on {reset_meshes} mesh(es).",
        )
        return {'FINISHED'}


class GHEB_PT_ShapeKeysPanel(bpy.types.Panel):
    bl_label = "ShapeMixer Entangle"
    bl_idname = "GHEB_PT_shape_keys_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'GHEB'
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        props = context.scene.gheb_shape_keys

        if len(props.slots) < _SHAPE_SLOT_COUNT:
            _ensure_shape_slot_init_timer()
            box = layout.box()
            box.label(text="Initializing Shape Slots...", icon='TIME')
            return

        from . import GHEB_Avatar
        controller = GHEB_Avatar.get_controller()
        config_locked = bool(
            controller is not None and controller.shape_configuration_locked()
        )

        for index, slot in enumerate(props.slots):
            if index >= _SHAPE_SLOT_COUNT:
                break
            box = layout.box()
            row = box.row(align=True)
            toggle = row.row(align=True)
            toggle.enabled = not config_locked
            toggle.prop(slot, "is_active", text=f"C{index + 1}  |  face_{index + 1:02d}")

            if slot.is_active:
                target_row = box.row()
                target_row.enabled = not config_locked
                target_row.prop(slot, "target_mesh", text="Target", icon='OUTLINER_OB_MESH')

                if slot.channel_id:
                    box.label(
                        text=(
                            f"{slot.hub_status} | CH_{slot.channel_id:03d} | "
                            f"UDP {slot.udp_port or '-'} | Route {slot.route_id or '-'} | "
                            f"Packets {slot.udp_packets}"
                        ),
                        icon='LINKED' if slot.route_id else 'INFO',
                    )

        if config_locked:
            layout.label(text="Reconnect to change Shape Slots.", icon='LOCKED')

        layout.separator()
        row = layout.row()
        row.scale_y = 1.2
        if not props.is_running:
            row.operator("gheb.start_shape_sync", text="Start SYNC", icon='PLAY')
        else:
            row.operator(
                "gheb.stop_shape_sync",
                text="Stop SYNC",
                icon='PAUSE',
                depress=True,
            )

        layout.operator("gheb.reset_shape_keys", icon='X')


@persistent
def _shape_load_post(_dummy):
    _ensure_shape_slot_init_timer()


def _shape_slot_init_timer():
    scenes=getattr(bpy.data,'scenes',None)
    if scenes is None:
        return 0.1
    if not hasattr(bpy.types.Scene,'gheb_shape_keys'):
        return None
    try:
        for scene in scenes:
            init_shape_slots(scene)
    except Exception as exc:
        print(f"[GHEB ShapeKeys] Slot initialization error: {exc}")
        return 0.25
    return None


def _ensure_shape_slot_init_timer():
    if not bpy.app.timers.is_registered(_shape_slot_init_timer):
        bpy.app.timers.register(_shape_slot_init_timer, first_interval=0.01)


_CLASSES = (
    GHEBShapeSlotProps,
    GHEBShapeKeyProps,
    GHEB_OT_StartShapeSync,
    GHEB_OT_StopShapeSync,
    GHEB_OT_ResetShapeKeys,
    GHEB_PT_ShapeKeysPanel,
)


def register():
    for cls in _CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.Scene.gheb_shape_keys = bpy.props.PointerProperty(type=GHEBShapeKeyProps)
    if _shape_load_post not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(_shape_load_post)
    _ensure_shape_slot_init_timer()


def unregister():
    global _shape_caches

    if bpy.app.timers.is_registered(_shape_slot_init_timer):
        try:
            bpy.app.timers.unregister(_shape_slot_init_timer)
        except Exception:
            pass
    if _shape_load_post in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(_shape_load_post)

    if hasattr(bpy.types.Scene, "gheb_shape_keys"):
        del bpy.types.Scene.gheb_shape_keys

    _shape_caches = {}

    for cls in reversed(_CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass
