import json
import math
import struct
import time

import bpy
import mathutils
import gpu
from gpu_extras.batch import batch_for_shader
from bpy.app.handlers import persistent

from .GHEB_GHubClient import GHubClient
from . import GHEB_Protocol as protocol
from . import GHEB_Timeline
from . import GHEB_ARP


_controller = None
_scene_reset_pending = False
_TIMER_INTERVAL = 0.016
_UI_REDRAW_INTERVAL = 0.25
# Keep UDP intake at 60 Hz, but commit facial values to Blender at a capped
# rate. Latest value wins, so transport latency stays low without hammering
# the dependency graph.
_SHAPE_APPLY_INTERVAL = 1.0 / 30.0
# Smart Swizzle cache stays unit-neutral; Translation Scale is a per-slot post-conversion multiplier.
_SS_CACHE_VERSION = 2


class GHEBSlotProps(bpy.types.PropertyGroup):
    delivery_mode: bpy.props.EnumProperty(
        name="Receiver", items=[('BONE','Original Bone Receiver','Original FBX/FK receiver'),
        ('ARP','ARP Direct: Arms FK / Legs IK','Drive existing ARP controls without Bind Only')], default='BONE')
    arp_source: bpy.props.PointerProperty(name="Imported FBX (capture only)",type=bpy.types.Object,
        poll=lambda self,obj:obj.type=='ARMATURE')
    arp_profile_json: bpy.props.StringProperty(default='')
    arp_ss_fingerprint: bpy.props.StringProperty(default='')
    arp_status: bpy.props.StringProperty(default='Capture a profile first',options={'SKIP_SAVE'})
    arp_max_fps: bpy.props.IntProperty(name="ARP Apply FPS",default=30,min=5,max=60)
    arp_eval_ms: bpy.props.FloatProperty(default=0.0,options={'SKIP_SAVE'})
    arp_changed_controls: bpy.props.IntProperty(default=0,options={'SKIP_SAVE'})
    is_active: bpy.props.BoolProperty(name="Active", default=False)
    # Retained for compatibility with existing .blend files.
    is_bake_target: bpy.props.BoolProperty(name="Bake", default=False)
    target_armature: bpy.props.PointerProperty(
        name="Armature",
        type=bpy.types.Object,
        poll=lambda self, obj: obj.type == 'ARMATURE',
    )
    root_bone: bpy.props.StringProperty(name="Root", default="")
    pelvis_1: bpy.props.StringProperty(name="Pelvis 1", default="")
    pelvis_2: bpy.props.StringProperty(name="Pelvis 2", default="")
    pelvis_3: bpy.props.StringProperty(name="Pelvis 3", default="")
    translation_scale: bpy.props.FloatProperty(
        name="Translation Scale",
        description=(
            "Multiplier applied to Root/Pelvis translation in both Live Sync "
            "and Offline Bake. 1.0 preserves the current GHEB behavior"
        ),
        default=1.0,
        min=0.0,
        soft_max=10.0,
        precision=4,
    )
    use_interpolation: bpy.props.BoolProperty(
        name="Body Interpolation",
        description="Smooth live Body synchronization using position and rotation interpolation",
        default=False,
    )
    lerp_speed: bpy.props.FloatProperty(
        name="Lerp Speed",
        description=(
            "Live Body smoothing speed. Lower values are softer; "
            "higher values follow the source more directly"
        ),
        default=12.0,
        min=0.5,
        max=60.0,
        precision=1,
    )
    has_ss_data: bpy.props.BoolProperty(default=False)
    ss_data_json: bpy.props.StringProperty(default="")
    ss_cache_version: bpy.props.IntProperty(default=0)

    # Per-slot runtime identity. UDP ports are transport details, not Slot IDs.
    hub_status: bpy.props.StringProperty(default="OFF", options={'SKIP_SAVE'})
    channel_id: bpy.props.IntProperty(default=0, options={'SKIP_SAVE'})
    route_id: bpy.props.IntProperty(default=0, options={'SKIP_SAVE'})
    udp_port: bpy.props.IntProperty(default=0, options={'SKIP_SAVE'})
    udp_packets: bpy.props.IntProperty(default=0, options={'SKIP_SAVE'})
    applied_frames: bpy.props.IntProperty(default=0, options={'SKIP_SAVE'})


class GHEBSceneProps(bpy.types.PropertyGroup):
    is_running: bpy.props.BoolProperty(default=False, options={'SKIP_SAVE'})
    slots: bpy.props.CollectionProperty(type=GHEBSlotProps)
    control_port: bpy.props.IntProperty(
        name="Control Port",
        description="G-HUB TCP Control Port",
        default=protocol.HUB_PORT,
        min=1,
        max=65535,
    )

    hub_status: bpy.props.StringProperty(default="DISCONNECTED", options={'SKIP_SAVE'})
    endpoint_id: bpy.props.IntProperty(default=0, options={'SKIP_SAVE'})

    # Compatibility fields retained for .blend files created before
    # per-slot runtime diagnostics were introduced.
    channel_id: bpy.props.IntProperty(default=0, options={'SKIP_SAVE'})
    route_id: bpy.props.IntProperty(default=0, options={'SKIP_SAVE'})
    udp_port: bpy.props.IntProperty(default=0, options={'SKIP_SAVE'})
    udp_packets: bpy.props.IntProperty(default=0, options={'SKIP_SAVE'})
    applied_frames: bpy.props.IntProperty(default=0, options={'SKIP_SAVE'})


class GHEBController:
    def __init__(self):
        self.client = GHubClient()

        # One Blender application == one Control TCP endpoint. Character Slots,
        # ShapeMixer and Timeline share that endpoint, but each Body Slot owns an
        # independent G-HUB channel / route / UDP socket.
        self.running = False
        self.avatar_enabled = False
        self.shape_enabled = False
        self.timeline_enabled = False
        self._disconnect_expected = False

        self._character = {
            i: {
                "channel_id": 0,
                "route_id": 0,
                "request_bones": {},
                "bone_bindings": {},
                "swizzle_offsets": {},
                "casc_rest_pos": {},
                "latest_poses": {},
                "smoothed_poses": {},
                "interpolation_time": 0.0,
                "arp_engine": None,
                "arp_next_apply": 0.0,
                "arp_pending": False,
                "arp_reapply": False,
                "arp_applying": False,
            }
            for i in range(protocol.CHARACTER_SLOT_COUNT)
        }

        # ShapeMixer receiver runtime is isolated per logical Character Slot.
        self._shape = {
            i: {
                "channel_id": 0,
                "route_id": 0,
                "latest_values": {},
                "pending_values": {},
                "next_apply_at": 0.0,
            }
            for i in range(protocol.CHARACTER_SLOT_COUNT)
        }

        self._last_ui_redraw = 0.0

    # --------------------------------------------------------
    # Character Slot helpers
    # --------------------------------------------------------

    @staticmethod
    def _character_udp_key(slot_index):
        return f"character:{int(slot_index)}"

    @staticmethod
    def _slot_label(slot_index):
        index = int(slot_index)
        return (
            f"C{index + 1} / {protocol.character_match_id(index)} / "
            f"local {protocol.character_local_id(index)}"
        )

    def _runtime(self, slot_index):
        try:
            index = int(slot_index)
        except Exception:
            return None
        return self._character.get(index)

    def _scene_slot(self, slot_index):
        scene = _get_scene()
        if scene is None or not hasattr(scene, "gheb_props"):
            return None
        index = int(slot_index)
        if index < 0 or index >= len(scene.gheb_props.slots):
            return None
        return scene.gheb_props.slots[index]

    def _configured_character_slots(self):
        scene = _get_scene()
        if scene is None:
            return []
        result = []
        for index, slot in enumerate(scene.gheb_props.slots):
            if index >= protocol.CHARACTER_SLOT_COUNT:
                break
            if slot.is_active and slot.target_armature is not None:
                result.append(index)
        return result

    def _find_character_slot_by_local_id(self, local_id):
        try:
            value = int(local_id)
        except Exception:
            return None
        index = value - 1
        if 0 <= index < protocol.CHARACTER_SLOT_COUNT:
            return index
        return None

    def _find_character_slot_by_channel_id(self, channel_id):
        try:
            value = int(channel_id)
        except Exception:
            return None
        if value <= 0:
            return None
        for index, runtime in self._character.items():
            if int(runtime["channel_id"]) == value:
                return index
        return None

    def _find_character_slot_by_route_id(self, route_id):
        try:
            value = int(route_id)
        except Exception:
            return None
        if value <= 0:
            return None
        for index, runtime in self._character.items():
            if int(runtime["route_id"]) == value:
                return index
        return None

    def get_character_channel_id(self, slot_index):
        runtime = self._runtime(slot_index)
        return int(runtime["channel_id"]) if runtime else 0

    def get_character_route_id(self, slot_index):
        runtime = self._runtime(slot_index)
        return int(runtime["route_id"]) if runtime else 0

    def get_character_udp_port(self, slot_index):
        return self.client.get_udp_port(self._character_udp_key(slot_index))

    def get_character_bone_bindings(self, slot_index):
        runtime = self._runtime(slot_index)
        return runtime["bone_bindings"] if runtime else {}

    def get_character_output_bindings(self, slot_index):
        runtime = self._runtime(slot_index)
        engine = runtime.get('arp_engine') if runtime else None
        return engine.output_bindings if engine else self.get_character_bone_bindings(slot_index)

    def arp_rest_ready(self, slot_index):
        runtime = self._runtime(slot_index)
        engine = runtime.get('arp_engine') if runtime else None
        if not engine:
            return True
        ready = {binding[1] for i,binding in runtime['bone_bindings'].items()
                 if i in runtime['swizzle_offsets'] and i in runtime['casc_rest_pos']}
        return engine.required_sources.issubset(ready)

    def arp_live_ready(self, slot_index):
        runtime = self._runtime(slot_index)
        engine = runtime.get('arp_engine') if runtime else None
        if not engine:
            return True
        ready = {runtime['bone_bindings'][i][1] for i,row in runtime['latest_poses'].items()
                 if i in runtime['bone_bindings'] and 'rot' in row}
        return self.arp_rest_ready(slot_index) and engine.required_sources.issubset(ready)

    def _apply_arp_direct(self, slot_index, advance_interpolation=True, force=False):
        runtime = self._runtime(slot_index)
        slot = self._scene_slot(slot_index)
        if not runtime or not slot or runtime.get('arp_applying'):
            return False
        if not self.arp_live_ready(slot_index):
            slot.arp_status = 'Waiting for all required FBX rotations / rest data'
            return False
        now = time.monotonic()
        if not force and now < runtime['arp_next_apply']:
            return False
        runtime['arp_next_apply'] = now + 1.0 / slot.arp_max_fps
        engine = runtime['arp_engine']
        samples = {}
        previous_time = runtime['interpolation_time']
        alpha = 1.0 - math.exp(-slot.lerp_speed * min(max(now-previous_time,0.0),0.1)) if previous_time else 1.0
        restore_only = runtime.get('arp_reapply', False) and not runtime.get('arp_fresh',False)
        for i,values in runtime['latest_poses'].items():
            if i not in runtime['bone_bindings']:
                continue
            previous = runtime['smoothed_poses'].get(i)
            row = {}
            for channel,value in values.items():
                if slot.use_interpolation and previous and channel in previous:
                    row[channel] = previous[channel].copy() if restore_only else (
                        previous[channel].slerp(value,alpha) if channel=='rot' else previous[channel].lerp(value,alpha))
                else:
                    row[channel] = value.copy()
            runtime['smoothed_poses'][i] = row
            samples[runtime['bone_bindings'][i][1]] = row
        runtime['arp_applying'] = True
        try:
            if engine.target != slot.target_armature or engine.target.name not in bpy.data.objects:
                raise ValueError('ARP target changed. Stop and reconnect.')
            engine.apply(samples)
            runtime['interpolation_time'] = now
            runtime['arp_pending'] = False
            runtime['arp_fresh'] = False
            runtime['arp_reapply'] = False
            if slot.use_interpolation and not restore_only:
                runtime['arp_pending'] = any(
                    abs(runtime['smoothed_poses'][i]['rot'].dot(row['rot'])) < 1-1e-6
                    or ('loc' in row and (runtime['smoothed_poses'][i]['loc']-row['loc']).length > 1e-5)
                    for i,row in runtime['latest_poses'].items() if 'rot' in row)
            slot.arp_eval_ms = engine.last_eval_ms
            slot.arp_changed_controls = engine.last_changed
            slot.arp_status = 'Live: %d controls / %.1f ms'%(len(engine.control_names),engine.last_eval_ms)
            return True
        except Exception as exc:
            runtime['arp_pending'] = False
            slot.arp_status = 'ERROR: '+str(exc)
            slot.is_active = False
            print('[GHEB ARP Direct] Slot paused:',exc)
            return False
        finally:
            runtime['arp_applying'] = False

    def get_character_swizzle_offsets(self, slot_index):
        runtime = self._runtime(slot_index)
        return runtime["swizzle_offsets"] if runtime else {}

    def get_character_rest_positions(self, slot_index):
        runtime = self._runtime(slot_index)
        return runtime["casc_rest_pos"] if runtime else {}

    def get_character_translation_scale(self, slot_index):
        slot = self._scene_slot(slot_index)
        if slot is None:
            return 1.0
        try:
            return max(0.0, float(slot.translation_scale))
        except Exception:
            return 1.0

    def character_configuration_locked(self):
        # Protocol v1 has no CHANNEL_REMOVE. Once a Character channel exists in
        # this Control session, changing the Slot set would leave stale channels
        # alive. Configuration therefore remains locked until endpoint reconnect.
        return self.running and any(
            int(runtime["channel_id"]) > 0
            for runtime in self._character.values()
        )

    def _set_slot_runtime_ui(self, slot_index, status=None):
        slot = self._scene_slot(slot_index)
        runtime = self._runtime(slot_index)
        if slot is None or runtime is None:
            return
        slot.channel_id = int(runtime["channel_id"])
        slot.route_id = int(runtime["route_id"])
        slot.udp_port = int(self.get_character_udp_port(slot_index))
        if status is not None:
            slot.hub_status = str(status)

    def _clear_character_slot_runtime(self, slot_index, close_udp=False):
        runtime = self._runtime(slot_index)
        if runtime is None:
            return
        if close_udp:
            self.client.close_udp(self._character_udp_key(slot_index))
        runtime["channel_id"] = 0
        runtime["route_id"] = 0
        runtime["request_bones"] = {}
        runtime["bone_bindings"] = {}
        runtime["swizzle_offsets"] = {}
        runtime["casc_rest_pos"] = {}
        runtime["latest_poses"] = {}
        runtime["smoothed_poses"] = {}
        runtime["interpolation_time"] = 0.0
        runtime['arp_engine'] = None
        runtime['arp_pending'] = False
        runtime['arp_reapply'] = False
        slot = self._scene_slot(slot_index)
        if slot is not None:
            slot.hub_status = "OFF"
            slot.channel_id = 0
            slot.route_id = 0
            slot.udp_port = 0
            slot.udp_packets = 0
            slot.applied_frames = 0

    def _clear_all_character_runtime(self, close_udp=False):
        for index in range(protocol.CHARACTER_SLOT_COUNT):
            self._clear_character_slot_runtime(index, close_udp=close_udp)

    def _register_active_character_channels(self):
        registered = 0
        for slot_index in self._configured_character_slots():
            runtime = self._runtime(slot_index)
            if runtime is None:
                continue
            if int(runtime["channel_id"]) <= 0:
                if self.client.send(protocol.channel_add_message(slot_index)):
                    self._set_slot_runtime_ui(slot_index, "REGISTERING")
                    registered += 1
                    print(f"[GHEB] CHANNEL_ADD / {self._slot_label(slot_index)}")
            elif int(runtime["route_id"]) > 0:
                self._activate_character_route(slot_index)
        return registered

    # --------------------------------------------------------
    # Shape Slot helpers
    # --------------------------------------------------------

    @staticmethod
    def _shape_udp_key(slot_index):
        index = int(slot_index)
        # Keep the original C1 receiver key for compatibility.
        return "shape" if index == 0 else f"shape:{index}"

    @staticmethod
    def _shape_slot_label(slot_index):
        index = int(slot_index)
        return (
            f"C{index + 1} / {protocol.shape_match_id(index)} / "
            f"local {protocol.shape_local_id(index)}"
        )

    def _shape_runtime(self, slot_index):
        try:
            index = int(slot_index)
        except Exception:
            return None
        return self._shape.get(index)

    def _scene_shape_slot(self, slot_index):
        scene = _get_scene()
        if scene is None or not hasattr(scene, "gheb_shape_keys"):
            return None
        try:
            index = int(slot_index)
        except Exception:
            return None
        props = scene.gheb_shape_keys
        if index < 0 or index >= len(props.slots):
            return None
        return props.slots[index]

    def _configured_shape_slots(self):
        scene = _get_scene()
        if scene is None or not hasattr(scene, "gheb_shape_keys"):
            return []
        try:
            from . import GHEB_ShapeKeys
            GHEB_ShapeKeys.init_shape_slots(scene)
            return GHEB_ShapeKeys.configured_shape_slots(scene)
        except Exception as exc:
            print(f"[GHEB ShapeKeys] Config read failed: {exc}")
            return []

    def _find_shape_slot_by_local_id(self, local_id):
        try:
            value = int(local_id)
        except Exception:
            return None
        index = value - 1001
        if 0 <= index < protocol.CHARACTER_SLOT_COUNT:
            return index
        return None

    def _find_shape_slot_by_channel_id(self, channel_id):
        try:
            value = int(channel_id)
        except Exception:
            return None
        if value <= 0:
            return None
        for index, runtime in self._shape.items():
            if int(runtime["channel_id"]) == value:
                return index
        return None

    def _find_shape_slot_by_route_id(self, route_id):
        try:
            value = int(route_id)
        except Exception:
            return None
        if value <= 0:
            return None
        for index, runtime in self._shape.items():
            if int(runtime["route_id"]) == value:
                return index
        return None

    def get_shape_channel_id(self, slot_index):
        runtime = self._shape_runtime(slot_index)
        return int(runtime["channel_id"]) if runtime else 0

    def get_shape_route_id(self, slot_index):
        runtime = self._shape_runtime(slot_index)
        return int(runtime["route_id"]) if runtime else 0

    def get_shape_udp_port(self, slot_index):
        return self.client.get_udp_port(self._shape_udp_key(slot_index))

    # Compatibility aliases for Character C1.
    @property
    def shape_channel_id(self):
        return self.get_shape_channel_id(0)

    @shape_channel_id.setter
    def shape_channel_id(self, value):
        runtime = self._shape_runtime(0)
        if runtime is not None:
            runtime["channel_id"] = int(value or 0)

    @property
    def shape_route_id(self):
        return self.get_shape_route_id(0)

    @shape_route_id.setter
    def shape_route_id(self, value):
        runtime = self._shape_runtime(0)
        if runtime is not None:
            runtime["route_id"] = int(value or 0)

    def shape_configuration_locked(self):
        # Protocol v1 has no CHANNEL_REMOVE. Once any Shape channel exists in
        # this Control session, the enabled Slot set stays locked until reconnect.
        return self.running and any(
            int(runtime["channel_id"]) > 0
            for runtime in self._shape.values()
        )

    def _set_shape_slot_runtime_ui(self, slot_index, status=None):
        slot = self._scene_shape_slot(slot_index)
        runtime = self._shape_runtime(slot_index)
        if slot is None or runtime is None:
            return
        slot.channel_id = int(runtime["channel_id"])
        slot.route_id = int(runtime["route_id"])
        slot.udp_port = int(self.get_shape_udp_port(slot_index))
        if status is not None:
            slot.hub_status = str(status)

        # Compatibility diagnostics mirror Character C1 only.
        if int(slot_index) == 0:
            scene = _get_scene()
            if scene and hasattr(scene, "gheb_shape_keys"):
                props = scene.gheb_shape_keys
                props.channel_id = slot.channel_id
                props.route_id = slot.route_id
                props.udp_port = slot.udp_port
                props.hub_status = slot.hub_status

    def _clear_shape_slot_runtime(self, slot_index, close_udp=False):
        runtime = self._shape_runtime(slot_index)
        if runtime is None:
            return
        if close_udp:
            self.client.close_udp(self._shape_udp_key(slot_index))
        runtime["channel_id"] = 0
        runtime["route_id"] = 0
        runtime["latest_values"] = {}
        runtime["pending_values"] = {}
        runtime["next_apply_at"] = 0.0
        slot = self._scene_shape_slot(slot_index)
        if slot is not None:
            slot.hub_status = "OFF"
            slot.channel_id = 0
            slot.route_id = 0
            slot.udp_port = 0
            slot.udp_packets = 0

    def _clear_all_shape_runtime(self, close_udp=False):
        for index in range(protocol.CHARACTER_SLOT_COUNT):
            self._clear_shape_slot_runtime(index, close_udp=close_udp)
        scene = _get_scene()
        if scene and hasattr(scene, "gheb_shape_keys"):
            props = scene.gheb_shape_keys
            props.hub_status = "OFF"
            props.channel_id = 0
            props.route_id = 0
            props.udp_port = 0
            props.udp_packets = 0

    def _register_active_shape_channels(self):
        registered = 0
        for slot_index in self._configured_shape_slots():
            runtime = self._shape_runtime(slot_index)
            if runtime is None:
                continue
            if int(runtime["channel_id"]) <= 0:
                if self.client.send(protocol.shape_channel_add_message(slot_index)):
                    self._set_shape_slot_runtime_ui(slot_index, "REGISTERING")
                    registered += 1
                    print(
                        f"[GHEB ShapeKeys] CHANNEL_ADD / "
                        f"{self._shape_slot_label(slot_index)}"
                    )
            elif int(runtime["route_id"]) > 0:
                self._set_shape_slot_runtime_ui(slot_index, "ROUTE ACTIVE")
        return registered

    # --------------------------------------------------------
    # Shared Endpoint Lifecycle
    # --------------------------------------------------------

    def _configure_connection(self):
        scene = _get_scene()
        port = protocol.HUB_PORT
        if scene is not None and hasattr(scene, "gheb_props"):
            port = int(scene.gheb_props.control_port)

        self.client.configure(
            host=protocol.HUB_HOST,
            port=port,
        )

    def _ensure_endpoint(self):
        if self.running:
            return

        self._configure_connection()
        self.running = True
        self._disconnect_expected = False
        self._set_runtime_status("CONNECTING")
        self.client.connect()

    def _disconnect_endpoint(self):
        self._disconnect_expected = True
        self.running = False

        try:
            GHEB_Timeline.before_endpoint_disconnect(self)
        except Exception as exc:
            print(f"[GHEB Timeline] Release error: {exc}")

        self.client.disconnect()
        GHEB_Timeline.on_endpoint_disconnected()
        self._clear_all_character_runtime(close_udp=False)
        self._clear_all_shape_runtime(close_udp=False)

        scene = _get_scene()
        if scene:
            props = scene.gheb_props
            props.hub_status = "DISCONNECTED"
            props.endpoint_id = 0
            props.channel_id = 0
            props.route_id = 0
            props.udp_port = 0
            props.udp_packets = 0
            props.applied_frames = 0

            if hasattr(scene, "gheb_shape_keys"):
                shape = scene.gheb_shape_keys
                shape.hub_status = "OFF"
                shape.channel_id = 0
                shape.route_id = 0
                shape.udp_port = 0

    # --------------------------------------------------------
    # Avatar feature
    # --------------------------------------------------------

    def start_avatar(self):
        self.avatar_enabled = True
        scene = _get_scene()
        if scene:
            scene.gheb_props.is_running = True
        self._ensure_endpoint()

        if self.client.endpoint_id:
            self._register_active_character_channels()

    def stop_avatar(self, send_stop=True):
        if GHEB_Timeline.is_baking() and GHEB_Timeline.bake_uses_character():
            GHEB_Timeline.cancel_offline_bake(
                self,
                reason="Character sync was stopped during Offline Bake.",
                send_cancel=True,
            )

        if send_stop:
            for runtime in self._character.values():
                route_id = int(runtime["route_id"])
                if route_id > 0:
                    self.client.send(
                        protocol.relay_message(route_id, {"command": "STOP"})
                    )

        self.avatar_enabled = False
        scene = _get_scene()
        if scene:
            scene.gheb_props.is_running = False

        # No CHANNEL_REMOVE exists in protocol v1. If ShapeMixer/Timeline still
        # uses this endpoint, Body channels remain allocated but idle until the
        # whole endpoint is reconnected.
        if not self.shape_enabled and not self.timeline_enabled:
            self._disconnect_endpoint()

    # --------------------------------------------------------
    # ShapeMixer feature (5 independent receiver Slots)
    # --------------------------------------------------------

    def start_shape(self):
        self.shape_enabled = True
        scene = _get_scene()
        if scene and hasattr(scene, "gheb_shape_keys"):
            try:
                from . import GHEB_ShapeKeys
                GHEB_ShapeKeys.init_shape_slots(scene)
            except Exception:
                pass
            shape = scene.gheb_shape_keys
            shape.is_running = True
            for slot_index in self._configured_shape_slots():
                self._set_shape_slot_runtime_ui(slot_index, "CONNECTING")

        self._ensure_endpoint()
        if self.client.endpoint_id:
            self._register_active_shape_channels()

    def stop_shape(self):
        if GHEB_Timeline.is_baking() and GHEB_Timeline.bake_uses_shape():
            GHEB_Timeline.cancel_offline_bake(
                self,
                reason="ShapeMixer sync was stopped during Offline Bake.",
                send_cancel=True,
            )

        self.shape_enabled = False
        for runtime in self._shape.values():
            runtime["latest_values"] = {}
            runtime["pending_values"] = {}
            runtime["next_apply_at"] = 0.0

        scene = _get_scene()
        if scene and hasattr(scene, "gheb_shape_keys"):
            shape = scene.gheb_shape_keys
            shape.is_running = False
            for index, slot in enumerate(shape.slots):
                if index >= protocol.CHARACTER_SLOT_COUNT:
                    break
                slot.hub_status = "OFF"
            shape.hub_status = "OFF"

        if not self.avatar_enabled and not self.timeline_enabled:
            self._disconnect_endpoint()

    # --------------------------------------------------------
    # Timeline feature
    # --------------------------------------------------------

    def start_timeline(self):
        self.timeline_enabled = True
        self._ensure_endpoint()
        GHEB_Timeline.start_sync(self)

    def stop_timeline(self):
        if self.timeline_enabled:
            GHEB_Timeline.stop_sync(self)
        self.timeline_enabled = False
        if not self.avatar_enabled and not self.shape_enabled:
            self._disconnect_endpoint()

    def stop_all(self, send_stop=True):
        if GHEB_Timeline.is_baking():
            GHEB_Timeline.cancel_offline_bake(
                self,
                reason="GHEB endpoint was stopped during Offline Bake.",
                send_cancel=True,
            )

        if send_stop:
            for runtime in self._character.values():
                route_id = int(runtime["route_id"])
                if route_id > 0:
                    self.client.send(
                        protocol.relay_message(route_id, {"command": "STOP"})
                    )

        self.avatar_enabled = False
        self.shape_enabled = False
        self.timeline_enabled = False

        scene = _get_scene()
        if scene:
            scene.gheb_props.is_running = False
            if hasattr(scene, "gheb_shape_keys"):
                scene.gheb_shape_keys.is_running = False

        self._disconnect_endpoint()

    def stop(self, send_stop=True):
        self.stop_all(send_stop=send_stop)

    # --------------------------------------------------------
    # Main-thread Tick
    # --------------------------------------------------------

    def tick(self):
        if not self.running:
            return

        for event_type, payload in self.client.poll_events():
            if event_type == "message":
                self._handle_message(payload)
            elif event_type == "status":
                self._set_runtime_status(str(payload))
                if self.shape_enabled:
                    self._set_shape_status(str(payload))
            elif event_type == "error":
                self._set_runtime_status("ERROR")
                if self.shape_enabled:
                    self._set_shape_status("ERROR")
                print(f"[GHEB] {payload}")
            elif event_type == "disconnected":
                if self.running and not self._disconnect_expected:
                    self._set_runtime_status("DISCONNECTED")
                    self._set_shape_status("DISCONNECTED")
                    self.client.close_udp()
                    self._clear_all_character_runtime(close_udp=False)
                    self._clear_all_shape_runtime(close_udp=False)
                    self.running = False
                    self.avatar_enabled = False
                    self.shape_enabled = False
                    self.timeline_enabled = False
                    scene = _get_scene()
                    if scene:
                        scene.gheb_props.is_running = False
                        if hasattr(scene, "gheb_shape_keys"):
                            scene.gheb_shape_keys.is_running = False
                    GHEB_Timeline.on_endpoint_disconnected()

        GHEB_Timeline.tick(self)

        # Offline Bake keeps packet ordering exact and therefore consumes every
        # packet from the selected Character Slot. Other Slot sockets are still
        # drained so stale live traffic never accumulates behind the bake.
        if GHEB_Timeline.is_baking():
            for slot_index in range(protocol.CHARACTER_SLOT_COUNT):
                packets = self.client.drain_udp_packets(
                    key=self._character_udp_key(slot_index),
                    max_packets=512,
                )
                for data in packets:
                    GHEB_Timeline.handle_bake_character_packet(
                        data, self, slot_index
                    )

            for slot_index in range(protocol.CHARACTER_SLOT_COUNT):
                shape_packets = self.client.drain_udp_packets(
                    key=self._shape_udp_key(slot_index),
                    max_packets=512,
                )
                for data in shape_packets:
                    GHEB_Timeline.handle_bake_shape_packet(
                        data, self, slot_index
                    )
            return

        # Body Live Sync: each Slot drains only its own receiver socket and owns
        # Bone IDs locally. There is no cross-Slot Bone ID offset.
        for slot_index in range(protocol.CHARACTER_SLOT_COUNT):
            runtime = self._runtime(slot_index)
            slot = self._scene_slot(slot_index)
            if runtime is None or slot is None:
                continue

            packet_count, latest = self.client.drain_udp(
                key=self._character_udp_key(slot_index)
            )
            if packet_count:
                slot.udp_packets += packet_count

            if (
                latest
                and self.avatar_enabled
                and slot.is_active
                and int(runtime["route_id"]) > 0
            ):
                if self._consume_live_packet(slot_index, latest):
                    if runtime.get('arp_engine'):
                        runtime['arp_pending'] = True
                        runtime['arp_fresh'] = True
                    else:
                        self._apply_latest_pose_to_bones(slot_index)
                        slot.applied_frames += 1
            if (runtime.get('arp_engine') and runtime.get('arp_pending')
                and self.avatar_enabled and slot.is_active and int(runtime['route_id'])>0):
                if self._apply_arp_direct(slot_index):
                    slot.applied_frames += 1

        # Shape Live Sync: each logical Character Slot drains its own face_NN
        # receiver socket and writes only to that Slot's target mesh.
        for slot_index in range(protocol.CHARACTER_SLOT_COUNT):
            runtime = self._shape_runtime(slot_index)
            slot = self._scene_shape_slot(slot_index)
            if runtime is None or slot is None:
                continue

            shape_packets = self.client.drain_udp_packets(
                key=self._shape_udp_key(slot_index),
                max_packets=512,
            )
            if shape_packets:
                slot.udp_packets += len(shape_packets)
                if slot_index == 0:
                    scene = _get_scene()
                    if scene and hasattr(scene, "gheb_shape_keys"):
                        scene.gheb_shape_keys.udp_packets += len(shape_packets)
                if (
                    self.shape_enabled
                    and slot.is_active
                    and int(runtime["route_id"]) > 0
                ):
                    self._consume_shape_packets(slot_index, shape_packets)

            if (
                self.shape_enabled
                and slot.is_active
                and runtime["pending_values"]
            ):
                self._flush_pending_shape_updates(slot_index)

    def _consume_shape_packets(self, slot_index, packets):
        runtime = self._shape_runtime(slot_index)
        if runtime is None:
            return
        updates = {}
        for data in packets:
            if not data:
                continue
            if len(data) >= 3 and data[:3] == b"GHS":
                continue
            try:
                message = data.decode("utf-8").strip()
            except Exception:
                continue
            separator = message.rfind(":")
            if separator <= 0 or separator >= len(message) - 1:
                continue
            shape_name = message[:separator]
            value_text = message[separator + 1:]
            try:
                value = float(value_text)
            except ValueError:
                continue
            updates[shape_name] = value

        if not updates:
            return
        runtime["latest_values"].update(updates)
        runtime["pending_values"].update(updates)

    def _flush_pending_shape_updates(self, slot_index, force=False):
        runtime = self._shape_runtime(slot_index)
        if runtime is None or not runtime["pending_values"]:
            return 0
        now = time.monotonic()
        if not force and now < float(runtime["next_apply_at"]):
            return 0
        scene = _get_scene()
        if scene is None:
            return 0
        updates = runtime["pending_values"]
        runtime["pending_values"] = {}
        runtime["next_apply_at"] = now + _SHAPE_APPLY_INTERVAL
        try:
            from . import GHEB_ShapeKeys
            return GHEB_ShapeKeys.apply_live_updates(
                scene, updates, slot_index=slot_index
            )
        except Exception as exc:
            print(
                f"[GHEB ShapeKeys] Apply error / "
                f"{self._shape_slot_label(slot_index)}: {exc}"
            )
            return 0

    def _set_shape_status(self, text, slot_index=None):
        scene = _get_scene()
        if scene is None or not hasattr(scene, "gheb_shape_keys"):
            return
        props = scene.gheb_shape_keys
        props.hub_status = str(text)
        indices = (
            [int(slot_index)]
            if slot_index is not None
            else self._configured_shape_slots()
        )
        for index in indices:
            slot = self._scene_shape_slot(index)
            if slot is not None:
                slot.hub_status = str(text)

    # --------------------------------------------------------
    # Smart Swizzle / Character control
    # --------------------------------------------------------

    def request_smart_swizzle(self, slot_index=None):
        if slot_index is None:
            return False
        runtime = self._runtime(slot_index)
        if not self.running or runtime is None or int(runtime["route_id"]) <= 0:
            return False
        request_bones = dict(runtime["request_bones"])
        if not request_bones:
            return False
        return self.client.send(
            protocol.relay_message(
                runtime["route_id"],
                {
                    "command": "SMART_SWIZZLE_REQUEST",
                    "rest_frame": 0,
                    "position_space": "local",
                    "request_bones": request_bones,
                },
            )
        )

    def _handle_message(self, message):
        msg_type = message.get("type", "")

        if msg_type == "ASSIGN":
            self.client.endpoint_id = int(message.get("endpoint_id", 0))
            self.client.session_id = int(message.get("session_id", 0))

            scene = _get_scene()
            if scene:
                scene.gheb_props.endpoint_id = self.client.endpoint_id
                scene.gheb_props.hub_status = "CONNECTED"
                if hasattr(scene, "gheb_shape_keys") and self.shape_enabled:
                    scene.gheb_shape_keys.hub_status = "CONNECTED"

            if self.avatar_enabled:
                self._register_active_character_channels()
            if self.shape_enabled:
                self._register_active_shape_channels()
            if self.timeline_enabled:
                GHEB_Timeline.on_endpoint_assigned(self)
            return

        if msg_type == "CHANNEL_REGISTERED":
            local_id = int(message.get("local_id", 0))
            channel_id = int(message.get("channel_id", 0))

            shape_slot_index = self._find_shape_slot_by_local_id(local_id)
            shape_runtime = (
                self._shape_runtime(shape_slot_index)
                if shape_slot_index is not None else None
            )
            if shape_runtime is not None and channel_id > 0:
                shape_runtime["channel_id"] = channel_id
                self._set_shape_slot_runtime_ui(shape_slot_index, "REGISTERED")
                return

            slot_index = self._find_character_slot_by_local_id(local_id)
            runtime = self._runtime(slot_index) if slot_index is not None else None
            if runtime is not None and channel_id > 0:
                runtime["channel_id"] = channel_id
                self._set_slot_runtime_ui(slot_index, "REGISTERED")
                return
            return

        if msg_type == "PORT_ASSIGN":
            channel_id = int(message.get("channel_id", 0))
            port = int(message.get("port", 0))
            if channel_id <= 0 or port <= 0:
                return

            shape_slot_index = self._find_shape_slot_by_channel_id(channel_id)
            if shape_slot_index is not None:
                key = self._shape_udp_key(shape_slot_index)
                try:
                    self.client.bind_udp(port, key=key)
                    self.client.send(protocol.ready_message(channel_id, port))
                    self._set_shape_slot_runtime_ui(shape_slot_index, "READY")
                    print(
                        f"[GHEB ShapeKeys] READY / "
                        f"{self._shape_slot_label(shape_slot_index)} / "
                        f"CH_{channel_id:03d} / UDP {port}"
                    )
                except Exception as exc:
                    print(
                        f"[GHEB ShapeKeys] UDP bind failed / "
                        f"{self._shape_slot_label(shape_slot_index)} / "
                        f"UDP {port}: {exc}"
                    )
                    self.client.send(
                        protocol.port_fail_message(channel_id, port, "bind_failed")
                    )
                return

            slot_index = self._find_character_slot_by_channel_id(channel_id)
            if slot_index is not None:
                key = self._character_udp_key(slot_index)
                try:
                    self.client.bind_udp(port, key=key)
                    self.client.send(protocol.ready_message(channel_id, port))
                    self._set_slot_runtime_ui(slot_index, "READY")
                    print(
                        f"[GHEB] READY / {self._slot_label(slot_index)} / "
                        f"CH_{channel_id:03d} / UDP {port}"
                    )
                except Exception as exc:
                    print(
                        f"[GHEB] UDP bind failed / {self._slot_label(slot_index)} / "
                        f"UDP {port}: {exc}"
                    )
                    self.client.send(
                        protocol.port_fail_message(channel_id, port, "bind_failed")
                    )
                return
            return

        if msg_type == "ROUTE":
            target_channel_id = int(message.get("target_channel_id", 0))

            shape_slot_index = self._find_shape_slot_by_channel_id(
                target_channel_id
            )
            shape_runtime = (
                self._shape_runtime(shape_slot_index)
                if shape_slot_index is not None else None
            )
            if shape_runtime is not None:
                shape_runtime["route_id"] = int(message.get("route_id", 0))
                shape_runtime["latest_values"] = {}
                shape_runtime["pending_values"] = {}
                self._set_shape_slot_runtime_ui(shape_slot_index, "ROUTE ACTIVE")
                print(
                    f"[GHEB ShapeKeys] ROUTE active / "
                    f"{self._shape_slot_label(shape_slot_index)} / "
                    f"UDP {self.get_shape_udp_port(shape_slot_index)} / "
                    f"Route {shape_runtime['route_id']}"
                )
                return

            slot_index = self._find_character_slot_by_channel_id(target_channel_id)
            runtime = self._runtime(slot_index) if slot_index is not None else None
            if runtime is not None:
                runtime["route_id"] = int(message.get("route_id", 0))
                runtime["latest_poses"] = {}
                runtime["smoothed_poses"] = {}
                runtime["interpolation_time"] = 0.0
                self._set_slot_runtime_ui(slot_index, "ROUTE ACTIVE")
                self._activate_character_route(slot_index)
                return
            return

        if msg_type == "ROUTE_REMOVE":
            route_id = int(message.get("route_id", 0))
            GHEB_Timeline.handle_bake_route_removed(route_id, self)

            shape_slot_index = self._find_shape_slot_by_route_id(route_id)
            shape_runtime = (
                self._shape_runtime(shape_slot_index)
                if shape_slot_index is not None else None
            )
            if shape_runtime is not None:
                shape_runtime["route_id"] = 0
                shape_runtime["latest_values"] = {}
                shape_runtime["pending_values"] = {}
                self._set_shape_slot_runtime_ui(
                    shape_slot_index,
                    "READY" if self.shape_enabled else "OFF",
                )
                shape_port = self.get_shape_udp_port(shape_slot_index)
                if int(shape_runtime["channel_id"]) > 0 and shape_port > 0:
                    self.client.send(
                        protocol.ready_message(
                            shape_runtime["channel_id"], shape_port
                        )
                    )
                return

            slot_index = self._find_character_slot_by_route_id(route_id)
            runtime = self._runtime(slot_index) if slot_index is not None else None
            if runtime is not None:
                runtime["route_id"] = 0
                runtime["latest_poses"] = {}
                runtime["smoothed_poses"] = {}
                runtime["interpolation_time"] = 0.0
                self._set_slot_runtime_ui(slot_index, "READY")
                char_port = self.get_character_udp_port(slot_index)
                if int(runtime["channel_id"]) > 0 and char_port > 0:
                    self.client.send(
                        protocol.ready_message(runtime["channel_id"], char_port)
                    )
                return
            return

        if msg_type == "TIMELINE_STATE":
            GHEB_Timeline.handle_timeline_state(message, self)
            return

        if msg_type == "RELAY":
            route_id = int(message.get("route_id", 0))
            payload = message.get("payload", {}) or {}

            if GHEB_Timeline.handle_bake_relay(route_id, payload, self):
                return

            slot_index = self._find_character_slot_by_route_id(route_id)
            if slot_index is not None:
                if payload.get("command", "") == "SMART_SWIZZLE_DATA":
                    self._process_smart_swizzle_data(slot_index, payload)
                return
            return

        if msg_type == "REJECT":
            reason = message.get("reason", "unknown")
            self._set_runtime_status(f"REJECTED: {reason}")
            if self.shape_enabled:
                self._set_shape_status(f"REJECTED: {reason}")
            return

    def _activate_character_route(self, slot_index):
        runtime = self._runtime(slot_index)
        slot = self._scene_slot(slot_index)
        if (
            not self.avatar_enabled
            or runtime is None
            or slot is None
            or not slot.is_active
            or int(runtime["route_id"]) <= 0
        ):
            return

        try:
            request_bones = self._build_request_bones(slot_index)
        except Exception as exc:
            slot.arp_status='ERROR: '+str(exc)
            slot.is_active=False
            self.client.send(protocol.relay_message(runtime['route_id'],{'command':'STOP'}))
            return
        runtime["request_bones"] = request_bones
        if not request_bones:
            print(f"[GHEB] START skipped / {self._slot_label(slot_index)} / no bones")
            return

        # Route identity + GHEC explicit Character Slot assignment own Character
        # identity. GHEB therefore sends bare Blender bone names. GHEC keeps the
        # old characterN: namespace only as a pre-v1.0.2 compatibility fallback.
        self.client.send(
            protocol.relay_message(
                runtime["route_id"],
                {
                    "command": "START",
                    "position_space": "local",
                    "request_bones": request_bones,
                },
            )
        )

        loaded = self._load_smart_swizzle_slot(slot_index, slot)
        if not loaded:
            self.request_smart_swizzle(slot_index)

        print(
            f"[GHEB] ROUTE active / {self._slot_label(slot_index)} / "
            f"UDP {self.get_character_udp_port(slot_index)} / "
            f"requested bones: {len(request_bones)} / "
            f"SS {'cached' if loaded else 'requested'}"
        )

    def _build_request_bones(self, slot_index):
        runtime = self._runtime(slot_index)
        slot = self._scene_slot(slot_index)
        if runtime is None or slot is None or not slot.target_armature:
            return {}

        result = {}
        bindings = {}
        armature = slot.target_armature
        next_id = 0
        runtime['arp_engine'] = None
        if slot.delivery_mode == 'ARP':
            profile = GHEB_ARP.parse_profile(slot.arp_profile_json, armature)
            engine = GHEB_ARP.ARPDirectEngine(profile, armature)
            GHEB_ARP.prepare_target(armature)
            runtime['arp_engine'] = engine
            runtime['arp_next_apply'] = 0.0
            runtime['arp_pending'] = False
            names = [node['name'] for node in profile['source_bones']]
            slot.arp_status = 'Waiting for Cascadeur rest data'
        else:
            names = [pb.name for pb in armature.pose.bones]
        for bone_name in names:
            if next_id >= 65535:
                break
            result[str(next_id)] = bone_name
            bindings[next_id] = (armature.name, bone_name)
            next_id += 1

        runtime["bone_bindings"] = bindings
        runtime["swizzle_offsets"] = {}
        runtime["casc_rest_pos"] = {}
        runtime["latest_poses"] = {}
        runtime["smoothed_poses"] = {}
        runtime["interpolation_time"] = 0.0
        return result

    def _load_smart_swizzle_slot(self, slot_index, slot):
        runtime = self._runtime(slot_index)
        if runtime is None or not slot.has_ss_data or not slot.ss_data_json:
            return False
        engine = runtime.get('arp_engine')
        if engine and slot.arp_ss_fingerprint != engine.profile['fingerprint']:
            slot.has_ss_data = False
            return False

        if int(getattr(slot, "ss_cache_version", 0)) != _SS_CACHE_VERSION:
            slot.has_ss_data = False
            slot.ss_data_json = ""
            slot.ss_cache_version = 0
            return False

        try:
            data = json.loads(slot.ss_data_json)
        except Exception:
            slot.has_ss_data = False
            slot.ss_data_json = ""
            return False

        # Older builds stored global Bone IDs. Current Bone IDs restart at
        # zero for each Character Slot, so migrate cached data by Bone name.
        by_name = {}
        if isinstance(data, dict):
            for entry in data.values():
                if isinstance(entry, dict) and entry.get("name"):
                    by_name[str(entry["name"])] = entry

        loaded_count = 0
        for b_id, binding in runtime["bone_bindings"].items():
            bone_name = binding[1]
            entry = by_name.get(bone_name)
            if not isinstance(entry, dict):
                continue
            try:
                q=mathutils.Quaternion(entry['q']);p=mathutils.Vector(entry['p'])
                if len(p)!=3 or not all(math.isfinite(v) for v in (*q,*p)) or q.magnitude<1e-8:
                    continue
                runtime["swizzle_offsets"][b_id] = q.normalized()
                runtime["casc_rest_pos"][b_id] = p
                loaded_count += 1
            except Exception:
                continue

        if loaded_count == 0:
            slot.has_ss_data = False
            return False
        if engine and not self.arp_rest_ready(slot_index):
            runtime['swizzle_offsets'].clear()
            runtime['casc_rest_pos'].clear()
            slot.has_ss_data = False
            return False
        return True

    def _process_smart_swizzle_data(self, slot_index, payload):
        slot = self._scene_slot(slot_index)
        runtime = self._runtime(slot_index)
        if slot is None or runtime is None:
            return

        bones = payload.get("bones", {}) or {}
        slot_data = {}
        matched = 0
        if runtime.get('arp_engine'):
            runtime['swizzle_offsets'].clear()
            runtime['casc_rest_pos'].clear()
            runtime['latest_poses'].clear()
            runtime['smoothed_poses'].clear()
            runtime['arp_pending']=False
            runtime['arp_engine'].last_poles.clear()

        for b_id_str, data in bones.items():
            try:
                b_id = int(b_id_str)
                binding = runtime["bone_bindings"].get(b_id)
                if binding is None:
                    continue
                rest_rot = data.get("rest_rot")
                rest_pos = data.get("rest_pos")
                if not rest_rot or not rest_pos or len(rest_rot)!=4 or len(rest_pos)!=3:
                    continue

                casc_rest_rot = mathutils.Quaternion(
                    (rest_rot[3], rest_rot[0], rest_rot[1], rest_rot[2])
                ).inverted()
                casc_rest_pos = mathutils.Vector(rest_pos)
                if (not all(math.isfinite(v) for v in (*casc_rest_rot,*casc_rest_pos))
                        or casc_rest_rot.magnitude<1e-8):
                    continue

                runtime["swizzle_offsets"][b_id] = casc_rest_rot
                runtime["casc_rest_pos"][b_id] = casc_rest_pos
                bone_name = binding[1]
                slot_data[str(b_id)] = {
                    "name": bone_name,
                    "q": [
                        casc_rest_rot.w,
                        casc_rest_rot.x,
                        casc_rest_rot.y,
                        casc_rest_rot.z,
                    ],
                    "p": [
                        casc_rest_pos.x,
                        casc_rest_pos.y,
                        casc_rest_pos.z,
                    ],
                }
                matched += 1
            except Exception as exc:
                print(f"[GHEB] Smart Swizzle bone parse error: {exc}")

        if slot_data:
            slot.ss_data_json = json.dumps(slot_data, separators=(",", ":"))
            slot.has_ss_data = True
            slot.ss_cache_version = _SS_CACHE_VERSION
        if runtime.get('arp_engine'):
            ready = self.arp_rest_ready(slot_index)
            slot.has_ss_data = ready
            slot.arp_ss_fingerprint = runtime['arp_engine'].profile['fingerprint'] if ready else ''
            mapped={binding[1] for i,binding in runtime['bone_bindings'].items() if i in runtime['swizzle_offsets']}
            missing=sorted(runtime['arp_engine'].required_sources-mapped)
            slot.arp_status = 'Rest data ready; waiting for live pose' if ready else 'Missing FBX: '+', '.join(missing[:3])

        print(
            f"[GHEB] Smart Swizzle ready / {self._slot_label(slot_index)} / "
            f"{matched} / {len(bones)} bones (frame {payload.get('rest_frame', 0)})"
        )

    # --------------------------------------------------------
    # Character packet / Scene application
    # --------------------------------------------------------

    def _consume_live_packet(self, slot_index, data):
        runtime = self._runtime(slot_index)
        if runtime is None or not data or len(data) < 5 or data[:3] != b"CEU":
            return False
        if runtime.get('arp_engine'):
            try:
                rows = self.decode_arp_packet(slot_index, data, header_size=5)
                for i,row in rows.items():
                    runtime['latest_poses'].setdefault(i,{}).update(row)
                return bool(rows)
            except Exception as exc:
                self._scene_slot(slot_index).arp_status = 'Invalid live packet: '+str(exc)
                return False

        try:
            bone_count = struct.unpack_from('<H', data, 3)[0]
            offset = 5
            changed = False

            for _ in range(bone_count):
                if offset + 3 > len(data):
                    break
                b_id, flags = struct.unpack_from('<H B', data, offset)
                offset += 3
                has_pos = (flags & 2) != 0
                has_rot = (flags & 1) != 0
                pos = None
                rot = None

                if has_pos:
                    if offset + 12 > len(data):
                        break
                    pos = mathutils.Vector(struct.unpack_from('<3f', data, offset))
                    offset += 12
                if has_rot:
                    if offset + 16 > len(data):
                        break
                    x, y, z, w = struct.unpack_from('<4f', data, offset)
                    rot = mathutils.Quaternion((w, x, y, z))
                    offset += 16

                offset_q = runtime["swizzle_offsets"].get(b_id)
                if offset_q is None:
                    continue

                pose = {}
                if rot is not None:
                    pose["rot"] = offset_q @ rot

                if pos is not None and self._is_location_bone(slot_index, b_id):
                    rest_pos = runtime["casc_rest_pos"].get(b_id)
                    if rest_pos is not None:
                        pose["loc"] = (
                            offset_q @ (pos - rest_pos)
                        ) * self.get_character_translation_scale(slot_index)

                if pose:
                    previous = runtime['latest_poses'].get(b_id, {})
                    previous.update(pose)
                    runtime["latest_poses"][b_id] = previous
                    changed = True

            return changed
        except Exception as exc:
            print(
                f"[GHEB] Character packet parse error / "
                f"{self._slot_label(slot_index)}: {exc}"
            )
            return False

    def decode_arp_packet(self, slot_index, data, header_size=5):
        runtime = self._runtime(slot_index)
        count = struct.unpack_from('<H', data, header_size-2)[0]
        offset = header_size
        rows = {}
        for _ in range(count):
            i,flags = struct.unpack_from('<HB',data,offset)
            offset += 3
            if flags & ~3 or not flags or i in rows:
                raise ValueError('Invalid flags / duplicate Bone ID')
            pos = rot = None
            if flags & 2:
                pos = mathutils.Vector(struct.unpack_from('<3f',data,offset));offset+=12
            if flags & 1:
                x,y,z,w = struct.unpack_from('<4f',data,offset);offset+=16
                rot = mathutils.Quaternion((w,x,y,z))
            if (rot and (not all(math.isfinite(v) for v in rot) or rot.magnitude<1e-8)) or (
                    pos is not None and not all(math.isfinite(v) for v in pos)):
                raise ValueError('Non-finite / zero transform')
            if i not in runtime['bone_bindings'] or i not in runtime['swizzle_offsets']:
                continue
            row={};q=runtime['swizzle_offsets'][i]
            if rot is not None:row['rot']=(q@rot).normalized()
            if pos is not None and i in runtime['casc_rest_pos']:
                row['loc']=(q@(pos-runtime['casc_rest_pos'][i]))*self.get_character_translation_scale(slot_index)
            rows[i]=row
        if offset!=len(data):
            raise ValueError('Unexpected packet length')
        return rows

    def convert_arp_bake_packet(self, slot_index, data):
        runtime=self._runtime(slot_index)
        rows=self.decode_arp_packet(slot_index,data,header_size=13)
        engine=runtime['arp_engine']
        samples={runtime['bone_bindings'][i][1]:row for i,row in rows.items()}
        if not self.arp_rest_ready(slot_index) or not engine.required_sources.issubset(
                {name for name,row in samples.items() if 'rot' in row}):
            raise ValueError('Incomplete ARP bake frame / rest data')
        if not runtime.get('arp_bake_snapshot'):
            runtime['arp_bake_snapshot']={n:(engine.target.pose.bones[n].rotation_mode,
                engine.target.pose.bones[n].matrix_basis.copy()) for n in engine.control_names}
            runtime['arp_bake_poles']={k:v.copy() for k,v in engine.last_poles.items()}
            engine.last_poles.clear()
        runtime['arp_applying']=True
        try:
            return engine.apply(samples)
        finally:
            runtime['arp_applying']=False

    def restore_arp_bake_pose(self, slot_index):
        runtime=self._runtime(slot_index)
        if not runtime or not runtime.get('arp_engine'):
            return
        engine=runtime['arp_engine']
        for name,(mode,basis) in runtime.pop('arp_bake_snapshot',{}).items():
            pb=engine.target.pose.bones.get(name)
            if pb:
                pb.rotation_mode=mode
                pb.matrix_basis=basis
        if 'arp_bake_poles' in runtime:
            engine.last_poles=runtime.pop('arp_bake_poles')
        bpy.context.view_layer.update()

    def _is_location_bone(self, slot_index, b_id):
        runtime = self._runtime(slot_index)
        slot = self._scene_slot(slot_index)
        if runtime is None or slot is None:
            return False
        binding = runtime["bone_bindings"].get(int(b_id))
        if binding is None:
            return False
        bone_name = binding[1]
        if runtime.get('arp_engine'):
            return True  # Store all source-local positions, including hierarchy roots.
        root_names = (
            slot.root_bone,
            slot.pelvis_1,
            slot.pelvis_2,
            slot.pelvis_3,
        )
        return any(name and name in bone_name for name in root_names)

    def _apply_latest_pose_to_bones(
        self,
        slot_index,
        advance_interpolation=True,
    ):
        runtime = self._runtime(slot_index)
        slot = self._scene_slot(slot_index)
        if runtime is None or slot is None:
            return

        latest = runtime["latest_poses"]
        if not latest:
            return
        if runtime.get('arp_engine'):
            return self._apply_arp_direct(slot_index, advance_interpolation)

        use_interpolation = bool(slot.use_interpolation)
        alpha = 1.0

        if use_interpolation and advance_interpolation:
            now = time.monotonic()
            previous_time = float(runtime.get("interpolation_time", 0.0))
            runtime["interpolation_time"] = now

            if previous_time > 0.0:
                dt = max(0.0, min(now - previous_time, 0.1))
                speed = max(0.5, float(slot.lerp_speed))
                alpha = 1.0 - math.exp(-speed * dt)

        smoothed = runtime["smoothed_poses"]

        for b_id, pose_data in latest.items():
            binding = runtime["bone_bindings"].get(b_id)
            if binding is None:
                continue

            armature_name, bone_name = binding
            armature = bpy.data.objects.get(armature_name)
            if not armature or armature.type != 'ARMATURE':
                continue

            pb = armature.pose.bones.get(bone_name)
            if pb is None:
                continue

            if not use_interpolation:
                applied = {}

                if "rot" in pose_data:
                    rotation = pose_data["rot"].copy()
                    pb.rotation_mode = 'QUATERNION'
                    pb.rotation_quaternion = rotation
                    applied["rot"] = rotation

                if "loc" in pose_data:
                    location = pose_data["loc"].copy()
                    pb.location = location
                    applied["loc"] = location

                if applied:
                    smoothed[b_id] = applied
                continue

            previous_pose = smoothed.get(b_id)

            # Frame evaluation can overwrite live pose channels. Restore the
            # current interpolated result without advancing interpolation twice.
            if not advance_interpolation and previous_pose is not None:
                applied = previous_pose
            else:
                applied = {}

                if "rot" in pose_data:
                    target_rot = pose_data["rot"]
                    if previous_pose is not None and "rot" in previous_pose:
                        applied["rot"] = previous_pose["rot"].slerp(
                            target_rot,
                            alpha,
                        )
                    else:
                        applied["rot"] = target_rot.copy()

                if "loc" in pose_data:
                    target_loc = pose_data["loc"]
                    if previous_pose is not None and "loc" in previous_pose:
                        applied["loc"] = previous_pose["loc"].lerp(
                            target_loc,
                            alpha,
                        )
                    else:
                        applied["loc"] = target_loc.copy()

                if applied:
                    smoothed[b_id] = applied

            if "rot" in applied:
                pb.rotation_mode = 'QUATERNION'
                pb.rotation_quaternion = applied["rot"]

            if "loc" in applied:
                pb.location = applied["loc"]

    def reapply_live_state_after_frame_evaluation(self, scene):
        if not self.running:
            return
        timeline = getattr(scene, "gheb_timeline", None)
        if timeline is not None and getattr(timeline, "is_baking", False):
            return

        if self.avatar_enabled:
            for slot_index in range(protocol.CHARACTER_SLOT_COUNT):
                runtime = self._runtime(slot_index)
                slot = self._scene_slot(slot_index)
                if (
                    runtime is not None
                    and slot is not None
                    and slot.is_active
                    and runtime["latest_poses"]
                ):
                    if runtime.get('arp_engine'):
                        if not runtime.get('arp_applying'):
                            runtime['arp_pending'] = True
                            runtime['arp_reapply'] = True
                        continue
                    self._apply_latest_pose_to_bones(
                        slot_index,
                        advance_interpolation=False,
                    )

        if self.shape_enabled:
            try:
                from . import GHEB_ShapeKeys
                for slot_index in range(protocol.CHARACTER_SLOT_COUNT):
                    runtime = self._shape_runtime(slot_index)
                    slot = self._scene_shape_slot(slot_index)
                    if (
                        runtime is None
                        or slot is None
                        or not slot.is_active
                        or not runtime["latest_values"]
                    ):
                        continue
                    if GHEB_ShapeKeys.has_local_shape_animation(
                        scene, slot_index=slot_index
                    ):
                        GHEB_ShapeKeys.apply_live_updates(
                            scene,
                            runtime["latest_values"],
                            slot_index=slot_index,
                        )
            except Exception as exc:
                print(f"[GHEB ShapeKeys] frame-post reapply error: {exc}")

    def apply_current_pose_as_keyframe(self, slot_index):
        """Insert one explicit keyframe for the current live pose of one Slot.

        Applying is a deliberate user action. STOP never mutates animation data.
        """
        scene = _get_scene()
        if scene is None:
            return 0

        runtime = self._runtime(slot_index)
        slot = self._scene_slot(slot_index)
        if runtime is None or slot is None or not slot.is_active:
            return 0
        if int(runtime["route_id"]) <= 0 or not runtime["bone_bindings"]:
            return 0

        curr_frame = scene.frame_current
        if runtime.get('arp_engine'):
            if not self.arp_live_ready(slot_index):
                return 0
            self._apply_arp_direct(slot_index, force=True)
            return runtime['arp_engine'].key_current(curr_frame)
        inserted = 0

        for b_id, binding in runtime["bone_bindings"].items():
            armature_name, bone_name = binding
            armature = bpy.data.objects.get(armature_name)
            if not armature or armature.type != 'ARMATURE':
                continue
            pb = armature.pose.bones.get(bone_name)
            if pb is None:
                continue

            if pb.keyframe_insert(
                data_path=(
                    "rotation_quaternion"
                    if pb.rotation_mode == 'QUATERNION'
                    else "rotation_euler"
                ),
                frame=curr_frame,
            ):
                inserted += 1

            if self._is_location_bone(slot_index, b_id):
                if pb.keyframe_insert(data_path="location", frame=curr_frame):
                    inserted += 1

        return inserted

    def _set_runtime_status(self, text):
        scene = _get_scene()
        if scene:
            scene.gheb_props.hub_status = text

def _get_scene():
    try:
        return bpy.context.scene
    except Exception:
        return None


def _tag_gheb_redraw():
    # Packet reception is timer-driven. Explicit redraw keeps runtime
    # counters and status current without relying on mouse movement.
    try:
        for window in bpy.context.window_manager.windows:
            for area in window.screen.areas:
                if area.type == 'VIEW_3D':
                    area.tag_redraw()
    except Exception:
        pass


def _gheb_timer():
    global _controller
    if _controller is None or not _controller.running:
        return None

    try:
        _controller.tick()
    except Exception as exc:
        print(f"[GHEB] Timer error: {exc}")

    return _TIMER_INTERVAL


def _gheb_ui_timer():
    if _controller is None or not _controller.running:
        return None
    _tag_gheb_redraw()
    return _UI_REDRAW_INTERVAL


def _ensure_timer():
    if not bpy.app.timers.is_registered(_gheb_timer):
        bpy.app.timers.register(_gheb_timer, first_interval=0.01, persistent=True)
    if not bpy.app.timers.is_registered(_gheb_ui_timer):
        bpy.app.timers.register(
            _gheb_ui_timer,
            first_interval=_UI_REDRAW_INTERVAL,
            persistent=True,
        )


def _get_or_create_controller():
    global _controller
    if _controller is None:
        _controller = GHEBController()
    return _controller


def get_controller():
    """Return the current shared endpoint controller without creating one."""
    return _controller


def start_shape_sync(scene):
    controller = _get_or_create_controller()
    controller.start_shape()
    _ensure_timer()
    return True


def stop_shape_sync(scene):
    global _controller
    if _controller is None:
        if scene is not None and hasattr(scene, "gheb_shape_keys"):
            scene.gheb_shape_keys.is_running = False
        return True

    _controller.stop_shape()

    if not _controller.running:
        _controller = None

    return True


def start_timeline_sync(scene):
    controller = _get_or_create_controller()
    controller.start_timeline()
    _ensure_timer()
    return True


def stop_timeline_sync(scene):
    global _controller
    if _controller is None:
        if scene is not None and hasattr(scene, "gheb_timeline"):
            scene.gheb_timeline.sync_enable = False
        return True

    _controller.stop_timeline()

    if not _controller.running:
        _controller = None

    return True


class GHEB_OT_Start(bpy.types.Operator):
    bl_idname = "gheb.start"
    bl_label = "Start Entangle"

    def execute(self, context):
        init_slots(context.scene)

        props = context.scene.gheb_props
        active_slots = []
        missing_targets = []
        for index, slot in enumerate(props.slots):
            if not slot.is_active:
                continue
            active_slots.append(index)
            if slot.target_armature is None:
                missing_targets.append(index)

        if missing_targets:
            labels = ", ".join(f"C{i + 1}" for i in missing_targets)
            self.report({'ERROR'}, f"Active Character Slot has no Armature: {labels}")
            return {'CANCELLED'}

        if not active_slots:
            self.report({'ERROR'}, "Enable at least one Character Slot before START Entangle.")
            return {'CANCELLED'}

        try:
            targets=set()
            for index in active_slots:
                slot=props.slots[index]
                if slot.target_armature.name in targets:
                    raise ValueError('Two slots cannot drive the same Armature.')
                targets.add(slot.target_armature.name)
                if slot.delivery_mode=='ARP':
                    GHEB_ARP.parse_profile(slot.arp_profile_json,slot.target_armature)
                    GHEB_ARP.check_target(slot.target_armature)
        except Exception as exc:
            self.report({'ERROR'},str(exc))
            return {'CANCELLED'}

        for slot in props.slots:
            slot.udp_packets = 0
            slot.applied_frames = 0

        controller = _get_or_create_controller()
        controller.start_avatar()
        props.is_running = True
        _ensure_timer()
        return {'FINISHED'}


class GHEB_OT_Stop(bpy.types.Operator):
    bl_idname = "gheb.stop"
    bl_label = "Stop Entangle"

    def execute(self, context):
        global _controller

        _ss_overlay_remove()

        if _controller is not None:
            _controller.stop_avatar(send_stop=True)
            if not _controller.running:
                _controller = None

        context.scene.gheb_props.is_running = False
        self.report({'INFO'}, "GHEB Entangle stopped.")
        return {'FINISHED'}


class GHEB_OT_ApplyPose(bpy.types.Operator):
    bl_idname = "gheb.apply_pose"
    bl_label = "Apply Pose"
    bl_description = "Insert a keyframe for this Slot's current live pose"

    slot_index: bpy.props.IntProperty()

    def execute(self, context):
        controller = get_controller()
        if (
            controller is None
            or not controller.running
            or controller.get_character_route_id(self.slot_index) <= 0
        ):
            self.report(
                {'WARNING'},
                "Start Entangle and wait for this Slot's ROUTE ACTIVE first.",
            )
            return {'CANCELLED'}

        inserted = controller.apply_current_pose_as_keyframe(self.slot_index)
        if inserted <= 0:
            self.report({'WARNING'}, "No live pose bindings were available to Apply.")
            return {'CANCELLED'}

        self.report(
            {'INFO'},
            f"Applied current GHEB pose at frame {context.scene.frame_current}.",
        )
        return {'FINISHED'}




# ---------------------------------------------------------------------------
# Smart Swizzle 3D diagnostic overlay
# ---------------------------------------------------------------------------

_ss_overlay_handle = None
_ss_overlay_state = {
    "enabled": False,
    "slot_index": 0,
    "bone_id": -1,
    "axis_size": 0.12,
    "show_rest": True,
    "show_live": True,
    "show_target": True,
    "show_actual": True,
    "show_all_status": False,
    "show_all_targets": False,
    "marker_size": 12.0,
}


def _ss_overlay_tag_redraw():
    try:
        wm = bpy.context.window_manager
        for window in wm.windows:
            screen = window.screen
            if screen is None:
                continue
            for area in screen.areas:
                if area.type == 'VIEW_3D':
                    area.tag_redraw()
    except Exception:
        pass


def _ss_overlay_remove():
    global _ss_overlay_handle

    if _ss_overlay_handle is not None:
        try:
            bpy.types.SpaceView3D.draw_handler_remove(
                _ss_overlay_handle, 'WINDOW'
            )
        except Exception:
            pass
        _ss_overlay_handle = None

    _ss_overlay_state["enabled"] = False
    _ss_overlay_tag_redraw()


def _ss_overlay_ensure():
    global _ss_overlay_handle

    if _ss_overlay_handle is None:
        _ss_overlay_handle = bpy.types.SpaceView3D.draw_handler_add(
            _ss_overlay_draw,
            (),
            'WINDOW',
            'POST_VIEW',
        )

    _ss_overlay_state["enabled"] = True
    _ss_overlay_tag_redraw()


def _ss_pose_matrix_from_channels(armature, pose_bone, loc, rot):
    """Resolve Blender local pose channels to an Armature-space pose matrix."""
    if armature is None or pose_bone is None:
        return None

    location = (
        loc.copy()
        if loc is not None
        else mathutils.Vector((0.0, 0.0, 0.0))
    )
    rotation = (
        rot.copy()
        if rot is not None
        else mathutils.Quaternion((1.0, 0.0, 0.0, 0.0))
    )
    scale = pose_bone.scale.copy()

    basis = mathutils.Matrix.LocRotScale(
        location,
        rotation,
        scale,
    )

    bone = pose_bone.bone
    parent = pose_bone.parent

    try:
        if parent is not None:
            return bone.convert_local_to_pose(
                basis,
                bone.matrix_local,
                parent_matrix=parent.matrix,
                parent_matrix_local=parent.bone.matrix_local,
            )

        return bone.convert_local_to_pose(
            basis,
            bone.matrix_local,
        )
    except Exception:
        return None


def _ss_overlay_matrices(data):
    """Build comparable world matrices for Rest / Live / Target / Actual."""
    armature = data.get("armature")
    pose_bone = data.get("pose_bone")
    live = data.get("live") or {}

    if armature is None or pose_bone is None:
        return {}

    world = armature.matrix_world
    rest_armature = pose_bone.bone.matrix_local.copy()
    rest_world = world @ rest_armature

    live_rot = live.get("rot")
    live_loc = live.get("loc")

    # "Live (mapped)" is the resolved local Smart Swizzle channel applied to
    # the Blender reference Bone without the current animated parent chain.
    # This exposes the mapped local sample itself.
    live_basis = mathutils.Matrix.LocRotScale(
        live_loc.copy() if live_loc is not None
        else mathutils.Vector((0.0, 0.0, 0.0)),
        live_rot.copy() if live_rot is not None
        else mathutils.Quaternion((1.0, 0.0, 0.0, 0.0)),
        mathutils.Vector((1.0, 1.0, 1.0)),
    )
    live_world = rest_world @ live_basis

    target_armature = _ss_pose_matrix_from_channels(
        armature,
        pose_bone,
        live_loc,
        live_rot,
    )
    target_world = (
        world @ target_armature
        if target_armature is not None
        else None
    )

    actual_world = world @ pose_bone.matrix

    result = {
        "rest": rest_world,
        "live": live_world if live else None,
        "target": target_world if live else None,
        "actual": actual_world,
    }
    return result


def _ss_draw_axis_triad(matrix, size, color):
    if matrix is None:
        return

    try:
        origin = matrix.translation
        basis = matrix.to_3x3().normalized()

        x_end = origin + (basis @ mathutils.Vector((size, 0.0, 0.0)))
        y_end = origin + (basis @ mathutils.Vector((0.0, size, 0.0)))
        z_end = origin + (basis @ mathutils.Vector((0.0, 0.0, size)))

        coords = [
            origin, x_end,
            origin, y_end,
            origin, z_end,
        ]

        shader = gpu.shader.from_builtin('UNIFORM_COLOR')
        batch = batch_for_shader(
            shader,
            'LINES',
            {"pos": coords},
        )
        shader.bind()
        shader.uniform_float("color", color)
        batch.draw(shader)

        point_batch = batch_for_shader(
            shader,
            'POINTS',
            {"pos": [origin]},
        )
        point_batch.draw(shader)
    except Exception:
        pass


def _ss_world_bone_point(binding):
    """Best available world-space point for a mapped Blender Bone."""
    armature_name, bone_name = binding
    armature = bpy.data.objects.get(armature_name)
    if armature is None or armature.type != 'ARMATURE':
        return None

    try:
        pb = armature.pose.bones.get(bone_name)
        if pb is not None:
            return armature.matrix_world @ pb.head
    except Exception:
        pass

    # Conservative fallback for partially-resolved diagnostic states.
    try:
        bone = armature.data.bones.get(bone_name)
        if bone is not None:
            return armature.matrix_world @ bone.head_local
    except Exception:
        pass

    return None


def _ss_draw_points(points, color, size):
    """Draw world-space cross markers.

    Blender 5.2 can ignore GPU point-size changes depending on the graphics
    backend. A small XYZ cross is deterministic and scales visibly with the
    Marker Size control.
    """
    if not points:
        return

    try:
        # "size" is a user-facing relative scale. Convert it to a compact
        # world-space marker extent suitable for normal character scales.
        extent = max(0.001, float(size) * 0.004)

        coords = []
        for point in points:
            p = point.copy()
            coords.extend([
                p + mathutils.Vector((-extent, 0.0, 0.0)),
                p + mathutils.Vector(( extent, 0.0, 0.0)),
                p + mathutils.Vector((0.0, -extent, 0.0)),
                p + mathutils.Vector((0.0,  extent, 0.0)),
                p + mathutils.Vector((0.0, 0.0, -extent)),
                p + mathutils.Vector((0.0, 0.0,  extent)),
            ])

        shader = gpu.shader.from_builtin('UNIFORM_COLOR')
        batch = batch_for_shader(
            shader,
            'LINES',
            {"pos": coords},
        )
        shader.bind()
        shader.uniform_float("color", color)
        gpu.state.line_width_set(2.0)
        batch.draw(shader)
    except Exception:
        pass


def _ss_collect_status_points(runtime):
    """Group mapped Bone positions by diagnostic state."""
    groups = {
        "READY": [],
        "NO_REST": [],
        "NO_LIVE": [],
        "NO_TARGET": [],
    }

    bindings = runtime.get("bone_bindings", {}) or {}
    for b_id, binding in bindings.items():
        state_key, _state_label = _ss_bone_state(
            runtime,
            b_id,
            binding,
        )
        point = _ss_world_bone_point(binding)
        if point is not None:
            groups.setdefault(state_key, []).append(point)

    return groups


def _ss_collect_all_target_matrices(controller, slot_index):
    """Resolve Target matrices for all mapped Bones with live data."""
    runtime = controller._runtime(slot_index)
    if runtime is None:
        return []

    result = []
    bindings = runtime.get("bone_bindings", {}) or {}

    for b_id in sorted(bindings):
        data = _ss_get_selected_bone_data(slot_index, b_id)
        if data is None or data.get("pose_bone") is None:
            continue

        live = data.get("live")
        if not live:
            continue

        matrices = _ss_overlay_matrices(data)
        target = matrices.get("target")
        if target is not None:
            result.append(target)

    return result


def _ss_draw_axis_batch(matrices, size, color):
    """Draw many same-color XYZ triads in one GPU batch."""
    coords = []

    for matrix in matrices:
        if matrix is None:
            continue
        try:
            origin = matrix.translation
            basis = matrix.to_3x3().normalized()

            coords.extend([
                origin,
                origin + (basis @ mathutils.Vector((size, 0.0, 0.0))),
                origin,
                origin + (basis @ mathutils.Vector((0.0, size, 0.0))),
                origin,
                origin + (basis @ mathutils.Vector((0.0, 0.0, size))),
            ])
        except Exception:
            continue

    if not coords:
        return

    try:
        shader = gpu.shader.from_builtin('UNIFORM_COLOR')
        batch = batch_for_shader(
            shader,
            'LINES',
            {"pos": coords},
        )
        shader.bind()
        shader.uniform_float("color", color)
        batch.draw(shader)
    except Exception:
        pass


def _ss_overlay_draw():
    if not _ss_overlay_state.get("enabled", False):
        return

    controller = get_controller()
    if controller is None or not getattr(controller, "running", False):
        return

    slot_index = int(_ss_overlay_state.get("slot_index", 0))
    runtime = controller._runtime(slot_index)
    if runtime is None:
        return

    bone_id = int(_ss_overlay_state.get("bone_id", -1))
    size = max(0.001, float(_ss_overlay_state.get("axis_size", 0.12)))

    try:
        gpu.state.blend_set('ALPHA')

        # ------------------------------------------------------
        # Whole-character status markers.
        # ------------------------------------------------------
        if _ss_overlay_state.get("show_all_status", False):
            marker_size = max(
                1.0,
                float(_ss_overlay_state.get("marker_size", 12.0)),
            )
            groups = _ss_collect_status_points(runtime)

            status_colors = {
                "READY":     (0.20, 1.00, 0.25, 0.95),
                "NO_REST":   (1.00, 0.35, 0.10, 0.98),
                "NO_LIVE":   (1.00, 0.85, 0.10, 0.98),
                "NO_TARGET": (1.00, 0.10, 0.10, 1.00),
            }

            for state_key, color in status_colors.items():
                _ss_draw_points(
                    groups.get(state_key, []),
                    color,
                    marker_size,
                )

        # ------------------------------------------------------
        # Whole-character resolved Target axes.
        # ------------------------------------------------------
        if _ss_overlay_state.get("show_all_targets", False):
            target_matrices = _ss_collect_all_target_matrices(
                controller,
                slot_index,
            )
            gpu.state.line_width_set(1.0)
            _ss_draw_axis_batch(
                target_matrices,
                size * 0.55,
                (1.00, 0.55, 0.10, 0.55),
            )

        # ------------------------------------------------------
        # Selected Bone diagnostic axes.
        # ------------------------------------------------------
        if bone_id >= 0:
            data = _ss_get_selected_bone_data(slot_index, bone_id)
            if data is not None:
                matrices = _ss_overlay_matrices(data)

                stages = [
                    ("rest",   "show_rest",   (0.70, 0.70, 0.70, 0.90)),
                    ("live",   "show_live",   (0.10, 0.85, 1.00, 0.95)),
                    ("target", "show_target", (1.00, 0.55, 0.10, 0.95)),
                    ("actual", "show_actual", (1.00, 0.15, 0.75, 0.95)),
                ]

                gpu.state.line_width_set(2.0)
                gpu.state.point_size_set(5.0)

                for matrix_key, toggle_key, color in stages:
                    if not _ss_overlay_state.get(toggle_key, True):
                        continue
                    _ss_draw_axis_triad(
                        matrices.get(matrix_key),
                        size,
                        color,
                    )

                # White selected-Bone point makes the inspected Bone obvious
                # when whole-character markers/axes are also visible.
                selected_point = _ss_world_bone_point(
                    (
                        data["armature_name"],
                        data["bone_name"],
                    )
                )
                if selected_point is not None:
                    _ss_draw_points(
                        [selected_point],
                        (1.00, 1.00, 1.00, 1.00),
                        max(
                            7.0,
                            float(
                                _ss_overlay_state.get(
                                    "marker_size",
                                    7.0,
                                )
                            ) + 2.0,
                        ),
                    )

    finally:
        try:
            gpu.state.line_width_set(1.0)
            gpu.state.point_size_set(1.0)
            gpu.state.blend_set('NONE')
        except Exception:
            pass


def _ss_visualizer_overlay_update(self, _context):
    try:
        _ss_overlay_state["slot_index"] = int(self.slot_key)
    except Exception:
        _ss_overlay_state["slot_index"] = 0

    try:
        _ss_overlay_state["bone_id"] = (
            int(self.bone_key)
            if self.bone_key not in {"", "NONE"}
            else -1
        )
    except Exception:
        _ss_overlay_state["bone_id"] = -1

    _ss_overlay_state["axis_size"] = float(self.axis_size)
    _ss_overlay_state["show_rest"] = bool(self.show_rest_axes)
    _ss_overlay_state["show_live"] = bool(self.show_live_axes)
    _ss_overlay_state["show_target"] = bool(self.show_target_axes)
    _ss_overlay_state["show_actual"] = bool(self.show_actual_axes)
    _ss_overlay_state["show_all_status"] = bool(
        self.show_all_status_markers
    )
    _ss_overlay_state["show_all_targets"] = bool(
        self.show_all_target_axes
    )
    _ss_overlay_state["marker_size"] = float(self.marker_size)

    if bool(self.show_3d_axes):
        _ss_overlay_ensure()
    else:
        _ss_overlay_remove()

    _ss_overlay_tag_redraw()


_SS_VISUALIZER_SLOT_ITEMS = [
    ('0', "C1", "Character Slot 1"),
    ('1', "C2", "Character Slot 2"),
    ('2', "C3", "Character Slot 3"),
    ('3', "C4", "Character Slot 4"),
    ('4', "C5", "Character Slot 5"),
]

# Blender requires Python to keep references to strings returned by dynamic
# EnumProperty callbacks. Keep the current Bone list alive here.
_ss_visualizer_bone_item_cache = []


def _ss_bone_state(runtime, b_id, binding):
    armature_name, bone_name = binding

    has_rest = b_id in runtime.get("swizzle_offsets", {})
    has_live = b_id in runtime.get("latest_poses", {})

    armature = bpy.data.objects.get(armature_name)
    has_target = bool(
        armature is not None
        and armature.type == 'ARMATURE'
        and armature.pose.bones.get(bone_name) is not None
    )

    if not has_target:
        return "NO_TARGET", "No Target"
    if not has_rest:
        return "NO_REST", "Missing Rest"
    if not has_live:
        return "NO_LIVE", "No Live"
    return "READY", "Ready"


def _ss_matching_bone_items(self):
    """Return only Bones that actually match the current Search / Filter."""
    controller = get_controller()
    if controller is None:
        return []

    try:
        slot_index = int(self.slot_key)
    except Exception:
        slot_index = 0

    runtime = controller._runtime(slot_index)
    if runtime is None:
        return []

    bindings = runtime.get("bone_bindings", {}) or {}
    if not bindings:
        return []

    search_text = str(getattr(self, "search_text", "") or "").strip().casefold()
    filter_mode = str(getattr(self, "filter_mode", "ALL") or "ALL")

    items = []
    for b_id in sorted(bindings):
        _armature_name, bone_name = bindings[b_id]
        state_key, state_label = _ss_bone_state(
            runtime, b_id, bindings[b_id]
        )

        if search_text and search_text not in bone_name.casefold():
            continue

        if filter_mode == "ISSUES" and state_key == "READY":
            continue
        if filter_mode == "READY" and state_key != "READY":
            continue
        if filter_mode == "NO_REST" and state_key != "NO_REST":
            continue
        if filter_mode == "NO_LIVE" and state_key != "NO_LIVE":
            continue
        if filter_mode == "NO_TARGET" and state_key != "NO_TARGET":
            continue

        items.append((
            str(int(b_id)),
            str(bone_name),
            f"Bone ID {int(b_id)} | {state_label}",
        ))

    return items


def _ss_visualizer_bone_items(self, _context):
    """Stable Bone Enum callback.

    The Enum item set is intentionally independent from Search / Filter and
    never reads self.bone_key. This avoids recursive RNA evaluation and stale
    Enum warnings when filters change.

    Search / Filter only choose the current selection from this stable list.
    """
    global _ss_visualizer_bone_item_cache

    controller = get_controller()
    if controller is None:
        _ss_visualizer_bone_item_cache = [
            ('NONE', "<No runtime>", "GHEB is not running")
        ]
        return _ss_visualizer_bone_item_cache

    try:
        slot_index = int(self.slot_key)
    except Exception:
        slot_index = 0

    runtime = controller._runtime(slot_index)
    if runtime is None:
        _ss_visualizer_bone_item_cache = [
            ('NONE', "<No runtime>", "No runtime for this Slot")
        ]
        return _ss_visualizer_bone_item_cache

    bindings = runtime.get("bone_bindings", {}) or {}
    if not bindings:
        _ss_visualizer_bone_item_cache = [
            ('NONE', "<No mapped bones>", "No mapped bones")
        ]
        return _ss_visualizer_bone_item_cache

    items = [
        ('NONE', "<No matching bones>", "No Bone selected")
    ]

    for b_id in sorted(bindings):
        _armature_name, bone_name = bindings[b_id]
        _state_key, state_label = _ss_bone_state(
            runtime, b_id, bindings[b_id]
        )
        items.append((
            str(int(b_id)),
            str(bone_name),
            f"Bone ID {int(b_id)} | {state_label}",
        ))

    # Blender requires Python to retain the strings backing dynamic Enum items.
    _ss_visualizer_bone_item_cache = items
    return _ss_visualizer_bone_item_cache


def _ss_visualizer_refresh_bone(self, context):
    """Apply Search / Filter using the stable all-Bone Enum."""
    try:
        matches = _ss_matching_bone_items(self)

        if matches:
            valid_ids = [item[0] for item in matches]
            current = str(getattr(self, "bone_key", "") or "")
            if current not in valid_ids:
                self.bone_key = valid_ids[0]
        else:
            self.bone_key = 'NONE'

        _ss_visualizer_overlay_update(self, context)
    except Exception:
        pass


def _ss_diag_counts(controller, slot_index):
    runtime = controller._runtime(slot_index) if controller is not None else None
    slot = controller._scene_slot(slot_index) if controller is not None else None

    if runtime is None:
        return {
            "route_active": False,
            "cached": False,
            "mapped": 0,
            "rest": 0,
            "live": 0,
            "targets": 0,
            "issues": 0,
        }

    bindings = runtime.get("bone_bindings", {}) or {}
    swizzles = runtime.get("swizzle_offsets", {}) or {}
    latest = runtime.get("latest_poses", {}) or {}

    target_count = 0
    issue_count = 0

    for b_id, binding in bindings.items():
        state_key, _state_label = _ss_bone_state(
            runtime, b_id, binding
        )

        if state_key != "NO_TARGET":
            target_count += 1
        if state_key != "READY":
            issue_count += 1

    return {
        "route_active": int(runtime.get("route_id", 0)) > 0,
        "cached": bool(slot and slot.has_ss_data),
        "mapped": len(bindings),
        "rest": len(swizzles),
        "live": len(latest),
        "targets": target_count,
        "issues": issue_count,
    }


def _ss_get_selected_bone_data(slot_index, bone_id):
    controller = get_controller()
    if controller is None:
        return None

    runtime = controller._runtime(int(slot_index))
    slot = controller._scene_slot(int(slot_index))
    if runtime is None or slot is None:
        return None

    b_id = int(bone_id)
    binding = runtime.get("bone_bindings", {}).get(b_id)
    if binding is None:
        return None

    armature_name, bone_name = binding
    armature = bpy.data.objects.get(armature_name)
    pb = (
        armature.pose.bones.get(bone_name)
        if armature is not None and armature.type == 'ARMATURE'
        else None
    )

    state_key, state_label = _ss_bone_state(runtime, b_id, binding)

    return {
        "controller": controller,
        "runtime": runtime,
        "slot": slot,
        "b_id": b_id,
        "armature": armature,
        "armature_name": armature_name,
        "bone_name": bone_name,
        "pose_bone": pb,
        "state_key": state_key,
        "state_label": state_label,
        "swizzle": runtime.get("swizzle_offsets", {}).get(b_id),
        "casc_rest_pos": runtime.get("casc_rest_pos", {}).get(b_id),
        "live": runtime.get("latest_poses", {}).get(b_id),
    }


def _ss_select_bone(context, data, frame=False):
    armature = data.get("armature")
    pb = data.get("pose_bone")
    if armature is None or pb is None:
        return False, "Resolved Blender target is missing."

    try:
        for obj in context.view_layer.objects:
            obj.select_set(False)
    except Exception:
        pass

    try:
        armature.select_set(True)
        context.view_layer.objects.active = armature
    except Exception as exc:
        return False, f"Could not activate Armature: {exc}"

    try:
        for bone in armature.data.bones:
            bone.select = False
        pb.bone.select = True
        armature.data.bones.active = pb.bone
    except Exception as exc:
        return False, f"Could not select Bone: {exc}"

    if not frame:
        return True, ""

    # Find a normal 3D View window and frame the selected bone there.
    try:
        wm = context.window_manager
        for window in wm.windows:
            screen = window.screen
            if screen is None:
                continue

            for area in screen.areas:
                if area.type != 'VIEW_3D':
                    continue

                region = next(
                    (r for r in area.regions if r.type == 'WINDOW'),
                    None,
                )
                if region is None:
                    continue

                space = area.spaces.active

                with context.temp_override(
                    window=window,
                    screen=screen,
                    area=area,
                    region=region,
                    space_data=space,
                    active_object=armature,
                    object=armature,
                ):
                    # Pose mode gives view_selected a precise selected-bone target.
                    if armature.mode != 'POSE':
                        try:
                            bpy.ops.object.mode_set(mode='POSE')
                        except Exception:
                            pass

                    bpy.ops.view3d.view_selected(use_all_regions=False)
                    return True, ""
    except Exception as exc:
        return False, f"Frame Bone failed: {exc}"

    return False, "No usable 3D View was found."


def _ss_format_vec3(value):
    if value is None:
        return "<missing>"
    try:
        return f"({value.x:.6f}, {value.y:.6f}, {value.z:.6f})"
    except Exception:
        return str(value)


def _ss_format_quat(value):
    if value is None:
        return "<missing>"
    try:
        return (
            f"(W {value.w:.6f}, X {value.x:.6f}, "
            f"Y {value.y:.6f}, Z {value.z:.6f})"
        )
    except Exception:
        return str(value)


def _ss_build_diagnostic_text(slot_index, data):
    controller = data["controller"]
    runtime = data["runtime"]
    counts = _ss_diag_counts(controller, int(slot_index))
    pb = data.get("pose_bone")
    live = data.get("live") or {}

    if pb is not None:
        if pb.rotation_mode == 'QUATERNION':
            actual_q = pb.rotation_quaternion.copy()
        else:
            actual_q = pb.rotation_euler.to_quaternion()
        actual_l = pb.location.copy()
    else:
        actual_q = None
        actual_l = None

    lines = [
        "GHEB Smart Swizzle Diagnostic",
        f"Character: C{int(slot_index) + 1}",
        f"Route: {'Active' if counts['route_active'] else 'Inactive'}",
        f"Reference Cache: {'Ready' if counts['cached'] else 'Missing'}",
        (
            f"Pipeline: Mapped {counts['mapped']} / "
            f"Rest {counts['rest']} / "
            f"Live {counts['live']} / "
            f"Targets {counts['targets']} / "
            f"Issues {counts['issues']}"
        ),
        "",
        f"Bone ID: {data['b_id']}",
        f"Request Name: {data['bone_name']}",
        f"State: {data['state_label']}",
        f"Armature: {data['armature_name']}",
        f"Cascadeur Rest Position: {_ss_format_vec3(data.get('casc_rest_pos'))}",
        f"Rest Quaternion: {_ss_format_quat(data.get('swizzle'))}",
        f"Resolved Live Position: {_ss_format_vec3(live.get('loc'))}",
        f"Resolved Live Rotation: {_ss_format_quat(live.get('rot'))}",
        f"Actual Local Position: {_ss_format_vec3(actual_l)}",
        f"Actual Local Rotation: {_ss_format_quat(actual_q)}",
    ]
    return "\n".join(lines)


class GHEB_OT_SSBoneAction(bpy.types.Operator):
    bl_idname = "gheb.ss_bone_action"
    bl_label = "SS Bone Action"
    bl_options = {'INTERNAL'}

    slot_index: bpy.props.IntProperty(default=0)
    bone_id: bpy.props.IntProperty(default=-1)
    action: bpy.props.EnumProperty(
        items=[
            ('SELECT', "Select Bone", ""),
            ('FRAME', "Frame Bone", ""),
            ('COPY', "Copy Diagnostic", ""),
        ],
        default='SELECT',
    )

    def execute(self, context):
        data = _ss_get_selected_bone_data(
            self.slot_index, self.bone_id
        )
        if data is None:
            self.report({'WARNING'}, "Smart Swizzle bone data is no longer available.")
            return {'CANCELLED'}

        if self.action == 'COPY':
            context.window_manager.clipboard = _ss_build_diagnostic_text(
                self.slot_index, data
            )
            self.report({'INFO'}, "Smart Swizzle diagnostic copied to clipboard.")
            return {'FINISHED'}

        ok, reason = _ss_select_bone(
            context,
            data,
            frame=(self.action == 'FRAME'),
        )
        if not ok:
            self.report({'WARNING'}, reason)
            return {'CANCELLED'}

        if self.action == 'FRAME':
            self.report({'INFO'}, f"Framed {data['bone_name']}.")
        else:
            self.report({'INFO'}, f"Selected {data['bone_name']}.")
        return {'FINISHED'}


class GHEB_OT_SSVisualizer(bpy.types.Operator):
    """Floating Smart Swizzle diagnostic panel."""

    bl_idname = "gheb.ss_visualizer"
    bl_label = "GHEB Smart Swizzle Visualizer"
    bl_description = "Open the floating Smart Swizzle diagnostic panel"
    bl_options = {'INTERNAL'}

    slot_index: bpy.props.IntProperty(default=0, options={'HIDDEN'})
    slot_key: bpy.props.EnumProperty(
        name="Character",
        items=_SS_VISUALIZER_SLOT_ITEMS,
        default='0',
        update=_ss_visualizer_refresh_bone,
    )
    search_text: bpy.props.StringProperty(
        name="Search",
        description="Filter Bone names",
        default="",
        update=_ss_visualizer_refresh_bone,
    )
    filter_mode: bpy.props.EnumProperty(
        name="Filter",
        items=[
            ('ALL', "All", "Show all mapped Bones"),
            ('ISSUES', "Issues", "Show only Bones with diagnostic issues"),
            ('READY', "Ready", "Show only complete Bones"),
            ('NO_REST', "Missing Rest", "Show Bones without Smart Swizzle Rest data"),
            ('NO_LIVE', "No Live", "Show Bones without live samples"),
            ('NO_TARGET', "No Target", "Show Bones without a resolved Blender target"),
        ],
        default='ALL',
        update=_ss_visualizer_refresh_bone,
    )
    bone_key: bpy.props.EnumProperty(
        name="Bone",
        items=_ss_visualizer_bone_items,
        update=_ss_visualizer_overlay_update,
    )
    show_3d_axes: bpy.props.BoolProperty(
        name="3D Diagnostic Axes",
        description="Draw Smart Swizzle diagnostic axes in the 3D View",
        default=False,
        update=_ss_visualizer_overlay_update,
    )
    show_rest_axes: bpy.props.BoolProperty(
        name="Rest",
        default=True,
        update=_ss_visualizer_overlay_update,
    )
    show_live_axes: bpy.props.BoolProperty(
        name="Live",
        default=True,
        update=_ss_visualizer_overlay_update,
    )
    show_target_axes: bpy.props.BoolProperty(
        name="Target",
        default=True,
        update=_ss_visualizer_overlay_update,
    )
    show_actual_axes: bpy.props.BoolProperty(
        name="Actual",
        default=True,
        update=_ss_visualizer_overlay_update,
    )
    axis_size: bpy.props.FloatProperty(
        name="Axis Size",
        description="3D diagnostic axis length in Blender units",
        default=0.12,
        min=0.001,
        max=10.0,
        precision=3,
        update=_ss_visualizer_overlay_update,
    )
    show_all_status_markers: bpy.props.BoolProperty(
        name="All Bone Status Markers",
        description="Show status markers for all mapped Bones in this Character",
        default=False,
        update=_ss_visualizer_overlay_update,
    )
    show_all_target_axes: bpy.props.BoolProperty(
        name="All Resolved Target Axes",
        description="Show resolved Target axes for all Bones with live samples",
        default=False,
        update=_ss_visualizer_overlay_update,
    )
    marker_size: bpy.props.FloatProperty(
        name="Marker Size",
        description=(
            "Relative world-space size of whole-character diagnostic markers"
        ),
        default=12.0,
        min=1.0,
        max=30.0,
        precision=1,
        update=_ss_visualizer_overlay_update,
    )

    def invoke(self, context, event):
        self.slot_key = str(max(0, min(4, int(self.slot_index))))

        items = _ss_visualizer_bone_items(self, context)
        if items:
            preferred_bone = int(_ss_overlay_state.get("bone_id", -1))
            preferred_key = str(preferred_bone) if preferred_bone >= 0 else ""
            valid_ids = [item[0] for item in items]
            self.bone_key = (
                preferred_key
                if preferred_key in valid_ids
                else items[0][0]
            )

        self.show_3d_axes = bool(
            _ss_overlay_state.get("enabled", False)
        )
        self.show_rest_axes = bool(
            _ss_overlay_state.get("show_rest", True)
        )
        self.show_live_axes = bool(
            _ss_overlay_state.get("show_live", True)
        )
        self.show_target_axes = bool(
            _ss_overlay_state.get("show_target", True)
        )
        self.show_actual_axes = bool(
            _ss_overlay_state.get("show_actual", True)
        )
        self.axis_size = float(
            _ss_overlay_state.get("axis_size", 0.12)
        )
        self.show_all_status_markers = bool(
            _ss_overlay_state.get("show_all_status", False)
        )
        self.show_all_target_axes = bool(
            _ss_overlay_state.get("show_all_targets", False)
        )
        self.marker_size = float(
            _ss_overlay_state.get("marker_size", 12.0)
        )

        _ss_visualizer_overlay_update(self, context)

        return context.window_manager.invoke_popup(self, width=780)

    def execute(self, context):
        return {'FINISHED'}

    def draw(self, context):
        layout = self.layout
        controller = get_controller()

        header = layout.row(align=True)
        header.label(text="Smart Swizzle Visualizer", icon='ORIENTATION_GIMBAL')
        header.prop(self, "slot_key", text="")

        try:
            slot_index = int(self.slot_key)
        except Exception:
            slot_index = 0

        if controller is None:
            box = layout.box()
            box.label(text="GHEB is not running.", icon='INFO')
            box.label(text="Start Entangle to inspect live diagnostics.")
            return

        runtime = controller._runtime(slot_index)
        slot = controller._scene_slot(slot_index)
        if runtime is None or slot is None:
            box = layout.box()
            box.label(text="No runtime data for this Character Slot.", icon='ERROR')
            return

        counts = _ss_diag_counts(controller, slot_index)

        status = layout.box()
        status.label(text=f"Character C{slot_index + 1}", icon='ARMATURE_DATA')

        row = status.row(align=True)
        row.label(
            text=("Route: Active" if counts["route_active"] else "Route: Inactive"),
            icon='LINKED' if counts["route_active"] else 'UNLINKED',
        )
        row.label(
            text=("Reference Cache: Ready" if counts["cached"] else "Reference Cache: Missing"),
            icon='CHECKMARK' if counts["cached"] else 'ERROR',
        )

        row = status.row(align=True)
        row.label(text=f"Mapped Bones: {counts['mapped']}")
        row.label(text=f"Cascadeur Rest: {counts['rest']}")
        row.label(text=f"Live Samples: {counts['live']}")
        row.label(text=f"Resolved Targets: {counts['targets']}")

        status.label(
            text=(
                "Diagnostic Pipeline: Complete"
                if counts["mapped"] > 0 and counts["issues"] == 0
                else f"Diagnostic Issues: {counts['issues']}"
            ),
            icon='CHECKMARK' if counts["mapped"] > 0 and counts["issues"] == 0 else 'INFO',
        )

        layout.separator()

        browser = layout.box()
        browser.label(text="Bone Browser", icon='BONE_DATA')

        row = browser.row(align=True)
        row.prop(self, "search_text", text="", icon='VIEWZOOM')
        row.prop(self, "filter_mode", text="")

        matches = _ss_matching_bone_items(self)

        if not matches:
            if self.bone_key != 'NONE':
                self.bone_key = 'NONE'
            browser.label(
                text="No Bone matches the current Search / Filter.",
                icon='INFO',
            )
            return

        valid_ids = [item[0] for item in matches]
        if self.bone_key not in valid_ids:
            self.bone_key = valid_ids[0]

        browser.prop(self, "bone_key", text="Bone")
        browser.label(
            text=f"Filter Matches: {len(matches)}",
            icon='FILTER',
        )

        try:
            b_id = int(self.bone_key)
        except Exception:
            browser.label(text="Invalid Bone selection.", icon='ERROR')
            return

        data = _ss_get_selected_bone_data(slot_index, b_id)
        if data is None:
            browser.label(text="Bone mapping is no longer available.", icon='ERROR')
            return

        armature = data["armature"]
        pb = data["pose_bone"]
        swizzle = data["swizzle"]
        casc_rest_pos = data["casc_rest_pos"]
        live = data["live"]
        bone_name = data["bone_name"]

        state_row = browser.row(align=True)
        state_row.label(text=f"Bone ID: {b_id}")
        state_row.label(text=f"Request: {bone_name}")
        state_row.label(
            text=f"State: {data['state_label']}",
            icon='CHECKMARK' if data["state_key"] == "READY" else 'INFO',
        )

        action_row = browser.row(align=True)

        op = action_row.operator(
            "gheb.ss_bone_action",
            text="Select Bone",
            icon='BONE_DATA',
        )
        op.slot_index = slot_index
        op.bone_id = b_id
        op.action = 'SELECT'

        op = action_row.operator(
            "gheb.ss_bone_action",
            text="Frame Bone",
            icon='ZOOM_SELECTED',
        )
        op.slot_index = slot_index
        op.bone_id = b_id
        op.action = 'FRAME'

        op = action_row.operator(
            "gheb.ss_bone_action",
            text="Copy Diagnostic",
            icon='COPYDOWN',
        )
        op.slot_index = slot_index
        op.bone_id = b_id
        op.action = 'COPY'

        overlay = layout.box()
        overlay.label(text="3D View Diagnostics", icon='ORIENTATION_GIMBAL')

        row = overlay.row(align=True)
        row.prop(
            self,
            "show_3d_axes",
            text="Show 3D Axes",
            toggle=True,
        )
        row.prop(self, "axis_size", text="Axis Size")

        row = overlay.row(align=True)
        row.enabled = self.show_3d_axes
        row.prop(self, "show_rest_axes", text="Rest", toggle=True)
        row.prop(self, "show_live_axes", text="Live", toggle=True)
        row.prop(self, "show_target_axes", text="Target", toggle=True)
        row.prop(self, "show_actual_axes", text="Actual", toggle=True)

        overlay.separator()
        overlay.label(text="Whole Character", icon='ARMATURE_DATA')

        row = overlay.row(align=True)
        row.enabled = self.show_3d_axes
        row.prop(
            self,
            "show_all_status_markers",
            text="All Bone Status Markers",
            toggle=True,
        )
        row.prop(
            self,
            "show_all_target_axes",
            text="All Resolved Target Axes",
            toggle=True,
        )

        row = overlay.row(align=True)
        row.enabled = (
            self.show_3d_axes
            and self.show_all_status_markers
        )
        row.prop(self, "marker_size", text="Marker Size")

        legend = overlay.column(align=True)
        legend.enabled = self.show_3d_axes
        legend.label(text="Selected: Rest = Gray | Live = Cyan")
        legend.label(text="Selected: Target = Orange | Actual = Magenta")
        legend.label(
            text="Status: Ready = Green | Missing Rest = Orange-Red"
        )
        legend.label(
            text="Status: No Live = Yellow | No Target = Red"
        )
        legend.label(
            text="White marker = currently inspected Bone"
        )

        details = layout.box()
        details.label(text="Selected Bone Pipeline", icon='CONSTRAINT_BONE')

        details.label(
            text="Cascadeur Rest: Ready" if swizzle is not None else "Cascadeur Rest: Missing",
            icon='CHECKMARK' if swizzle is not None else 'ERROR',
        )
        details.label(
            text="Cascadeur Live: Seen" if live is not None else "Cascadeur Live: No Sample",
            icon='CHECKMARK' if live is not None else 'INFO',
        )
        details.label(
            text="Blender Target: Resolved" if pb is not None else "Blender Target: Missing",
            icon='CHECKMARK' if pb is not None else 'ERROR',
        )

        if casc_rest_pos is not None:
            details.label(
                text=(
                    "Rest Position: "
                    f"({casc_rest_pos.x:.4f}, {casc_rest_pos.y:.4f}, {casc_rest_pos.z:.4f})"
                )
            )

        if swizzle is not None:
            details.label(
                text=(
                    "Rest Quaternion: "
                    f"W {swizzle.w:.4f}  X {swizzle.x:.4f}  "
                    f"Y {swizzle.y:.4f}  Z {swizzle.z:.4f}"
                )
            )

        if live is not None:
            live_rot = live.get("rot")
            live_loc = live.get("loc")

            if live_rot is not None:
                details.label(
                    text=(
                        "Resolved Live Rotation: "
                        f"W {live_rot.w:.4f}  X {live_rot.x:.4f}  "
                        f"Y {live_rot.y:.4f}  Z {live_rot.z:.4f}"
                    )
                )
            if live_loc is not None:
                details.label(
                    text=(
                        "Resolved Live Position: "
                        f"({live_loc.x:.4f}, {live_loc.y:.4f}, {live_loc.z:.4f})"
                    )
                )

        if pb is not None:
            if pb.rotation_mode == 'QUATERNION':
                actual_q = pb.rotation_quaternion
            else:
                actual_q = pb.rotation_euler.to_quaternion()

            actual_l = pb.location
            details.separator()
            details.label(
                text=(
                    "Actual Local Rotation: "
                    f"W {actual_q.w:.4f}  X {actual_q.x:.4f}  "
                    f"Y {actual_q.y:.4f}  Z {actual_q.z:.4f}"
                )
            )
            details.label(
                text=(
                    "Actual Local Position: "
                    f"({actual_l.x:.4f}, {actual_l.y:.4f}, {actual_l.z:.4f})"
                )
            )

        footer = layout.box()
        footer.label(
            text="Smart Swizzle Diagnostics",
            icon='INFO',
        )
        footer.label(
            text="Use Search, Filters, 3D diagnostics, and Copy Diagnostic to isolate mapping problems."
        )


class GHEB_OT_SmartSwizzle(bpy.types.Operator):
    bl_idname = "gheb.smart_swizzle"
    bl_label = "Smart Swizzle"
    slot_index: bpy.props.IntProperty()

    def execute(self, context):
        if (
            _controller is None
            or not _controller.running
            or _controller.get_character_route_id(self.slot_index) <= 0
        ):
            self.report({'WARNING'}, "Start Entangle and wait for this Slot's ROUTE ACTIVE first.")
            return {'CANCELLED'}

        if not _controller.request_smart_swizzle(self.slot_index):
            self.report({'WARNING'}, "No bones are available for this Slot.")
            return {'CANCELLED'}

        self.report({'INFO'}, f"Smart Swizzle requested for C{self.slot_index + 1}.")
        return {'FINISHED'}


class GHEB_OT_ClearSS(bpy.types.Operator):
    bl_idname = "gheb.clear_ss"
    bl_label = "Clear Smart Swizzle Cache"
    slot_index: bpy.props.IntProperty()

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        if self.slot_index >= len(context.scene.gheb_props.slots):
            return {'CANCELLED'}
        slot = context.scene.gheb_props.slots[self.slot_index]
        slot.has_ss_data = False
        slot.ss_data_json = ""
        slot.ss_cache_version = 0
        slot.arp_ss_fingerprint = ''
        if _controller is not None:
            runtime=_controller._runtime(self.slot_index)
            if runtime:
                runtime['swizzle_offsets'].clear()
                runtime['casc_rest_pos'].clear()
                runtime['latest_poses'].clear()
                runtime['smoothed_poses'].clear()
                runtime['arp_pending']=False
        return {'FINISHED'}


class GHEB_PT_MainPanel(bpy.types.Panel):
    bl_label = "GHEB ARP Direct"
    bl_idname = "GHEB_PT_main_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'GHEB'

    def draw(self, context):
        layout = self.layout
        props = context.scene.gheb_props

        # Blender 5.2+: never mutate Scene/ID data from Panel.draw().
        if len(props.slots) < 5:
            _ensure_slot_init_timer()
            box = layout.box()
            box.label(text="Initializing GHEB slots...", icon='TIME')

        controller = get_controller()
        endpoint_active = bool(
            controller is not None and controller.running
        )

        connection_box = layout.box()
        connection_box.label(text="G-HUB Control", icon='NETWORK_DRIVE')
        row = connection_box.row(align=True)
        row.label(text=protocol.HUB_HOST)
        port_row = row.row(align=True)
        port_row.enabled = not endpoint_active
        port_row.prop(props, "control_port", text="Port")

        if endpoint_active:
            connection_box.label(
                text="Reconnect to change the Control Port.",
                icon='LOCKED',
            )

        row = layout.row()
        row.scale_y = 1.5
        if not props.is_running:
            row.operator("gheb.start", text="Start Entangle", icon='PLAY')
        else:
            row.operator(
                "gheb.stop",
                text="Stop Entangle",
                icon='PAUSE',
                depress=True,
            )

        status_box = layout.box()
        row = status_box.row(align=True)
        row.label(text=f"G-HUB: {props.hub_status}")
        if props.endpoint_id:
            row.label(text=f"EP_{props.endpoint_id:03d}")

        layout.separator()

        config_locked = bool(
            controller is not None and controller.character_configuration_locked()
        )

        for i, slot in enumerate(props.slots):
            box = layout.box()
            row = box.row()
            slot_toggle = row.row()
            slot_toggle.enabled = not config_locked
            slot_toggle.prop(
                slot,
                "is_active",
                text=f"C{i + 1} ({protocol.character_match_id(i)})",
            )
            if slot.is_active:
                apply_row = row.row()
                apply_row.enabled = bool(
                    props.is_running
                    and controller is not None
                    and controller.get_character_route_id(i) > 0
                )
                op_apply = apply_row.operator(
                    "gheb.apply_pose",
                    text="Apply",
                )
                op_apply.slot_index = i

            if slot.is_active:
                if slot.channel_id:
                    box.label(
                        text=(
                            f"{slot.hub_status} | CH_{slot.channel_id:03d} | "
                            f"UDP {slot.udp_port or '-'} | Route {slot.route_id or '-'} | "
                            f"Packets {slot.udp_packets}"
                        ),
                        icon='LINKED' if slot.route_id else 'INFO',
                    )

                col = box.column(align=True)
                col.enabled = not config_locked
                col.prop(slot, "delivery_mode")
                col.prop(slot, "target_armature")
                col.separator()
                if slot.delivery_mode=='ARP':
                    col.prop(slot,'arp_source')
                    op=col.operator('gheb.arp_capture',text='Capture FBX -> ARP Profile',icon='BONE_DATA');op.slot_index=i
                    row=col.row(align=True)
                    op=row.operator('gheb.arp_import_profile',text='Import Profile');op.slot_index=i
                    op=row.operator('gheb.arp_export_profile',text='Export Profile');op.slot_index=i
                    box.prop(slot,'arp_max_fps')
                    box.label(text=slot.arp_status)
                    box.label(text='Arms FK / Legs IK / no Bind Only')
                else:
                    col.prop(slot, "root_bone")
                    col.prop(slot, "pelvis_1")
                    col.prop(slot, "pelvis_2")
                    col.prop(slot, "pelvis_3")

                scale_col = box.column(align=True)
                scale_col.prop(
                    slot,
                    "translation_scale",
                    text="Translation Scale",
                )

                interp_col = box.column(align=True)
                interp_col.prop(
                    slot,
                    "use_interpolation",
                    text="Body Interpolation",
                )
                if slot.use_interpolation:
                    interp_col.prop(
                        slot,
                        "lerp_speed",
                        text="Lerp Speed",
                    )

                row_ss = box.row(align=True)
                if slot.has_ss_data:
                    op = row_ss.operator(
                        "gheb.smart_swizzle",
                        text="SS Cached",
                        icon='CHECKMARK',
                        depress=True,
                    )
                    op.slot_index = i
                    clear_op = row_ss.operator("gheb.clear_ss", text="", icon='TRASH')
                    clear_op.slot_index = i
                else:
                    op = row_ss.operator(
                        "gheb.smart_swizzle",
                        text="Run Smart Swizzle",
                        icon='FILE_REFRESH',
                    )
                    op.slot_index = i

                if slot.delivery_mode!='ARP':
                    vis_op = row_ss.operator('gheb.ss_visualizer',text='SS Visualizer',icon='VIEWZOOM')
                    vis_op.slot_index = i

        if config_locked:
            layout.label(text="Reconnect to change Character Slots.", icon='LOCKED')

        layout.separator()
        GHEB_Timeline.draw_timeline_section(
            layout,
            context,
        )


def init_slots(scene):
    """Ensure the scene owns the five GHEB slots outside UI draw context."""
    if scene is None or not hasattr(scene, "gheb_props"):
        return

    props = scene.gheb_props
    while len(props.slots) < 5:
        index = len(props.slots)
        slot = props.slots.add()
        # C1 is enabled by default.
        slot.is_active = (index == 0)


def _slot_init_timer():
    global _scene_reset_pending
    # addon_utils.enable() runs register() under RestrictBlend. Only the
    # deferred callback or a real load_post may access scene datablocks.
    scenes=getattr(bpy.data,'scenes',None)
    if scenes is None:
        return 0.1
    if not hasattr(bpy.types.Scene,'gheb_props'):
        return None
    try:
        for scene in scenes:
            init_slots(scene)
            if _scene_reset_pending:
                props=scene.gheb_props
                props.is_running=False
                props.hub_status='DISCONNECTED'
                props.endpoint_id=0
                for slot in props.slots:
                    slot.hub_status='OFF'
                    slot.channel_id=slot.route_id=slot.udp_port=slot.udp_packets=slot.applied_frames=0
                    slot.arp_status='Profile saved; disconnected' if slot.arp_profile_json else 'Capture a profile first'
                if hasattr(scene,'gheb_shape_keys'):scene.gheb_shape_keys.is_running=False
                if hasattr(scene,'gheb_timeline'):scene.gheb_timeline.is_baking=False
        _scene_reset_pending=False
    except Exception as exc:
        print(f"[GHEB] Slot initialization error: {exc}")
        return 0.25
    return None


def _ensure_slot_init_timer():
    if not bpy.app.timers.is_registered(_slot_init_timer):
        bpy.app.timers.register(_slot_init_timer, first_interval=0.01)


@persistent
def _gheb_frame_change_post(scene, _depsgraph=None):
    # Proven CEB technique: Blender's animation evaluation may overwrite the
    # live pose during playback. Restore the latest GHEB state after evaluation.
    controller = _controller
    if controller is None or not controller.running:
        return
    try:
        controller.reapply_live_state_after_frame_evaluation(scene)
    except Exception as exc:
        print(f"[GHEB] frame_change_post error: {exc}")


@persistent
def _gheb_load_post(_dummy):
    global _scene_reset_pending
    _scene_reset_pending=True
    if _slot_init_timer() is not None:
        _ensure_slot_init_timer()


@persistent
def _gheb_load_pre(_dummy):
    global _controller
    if _controller:
        try:
            _controller.stop(send_stop=False)
        except Exception:
            pass
        _controller=None
    GHEB_Timeline.reset_runtime()


_CLASSES = (
    GHEBSlotProps,
    GHEBSceneProps,
    GHEB_OT_Start,
    GHEB_OT_Stop,
    GHEB_OT_ApplyPose,
    GHEB_OT_SSBoneAction,
    GHEB_OT_SSVisualizer,
    GHEB_OT_SmartSwizzle,
    GHEB_OT_ClearSS,
    GHEB_PT_MainPanel,
)


def register():
    global _scene_reset_pending
    for cls in _CLASSES:
        bpy.utils.register_class(cls)

    bpy.types.Scene.gheb_props = bpy.props.PointerProperty(type=GHEBSceneProps)

    if _gheb_load_post not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(_gheb_load_post)
    if _gheb_load_pre not in bpy.app.handlers.load_pre:
        bpy.app.handlers.load_pre.append(_gheb_load_pre)
    if _gheb_frame_change_post not in bpy.app.handlers.frame_change_post:
        bpy.app.handlers.frame_change_post.append(_gheb_frame_change_post)

    _scene_reset_pending=True
    _ensure_slot_init_timer()


def unregister():
    _ss_overlay_remove()
    global _controller, _scene_reset_pending
    _scene_reset_pending=False

    if _controller is not None:
        try:
            _controller.stop(send_stop=True)
        except Exception:
            pass
        _controller = None

    for timer in (_gheb_timer, _gheb_ui_timer, _slot_init_timer):
        if bpy.app.timers.is_registered(timer):
            try:
                bpy.app.timers.unregister(timer)
            except Exception:
                pass

    if _gheb_load_post in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(_gheb_load_post)
    if _gheb_load_pre in bpy.app.handlers.load_pre:
        bpy.app.handlers.load_pre.remove(_gheb_load_pre)
    if _gheb_frame_change_post in bpy.app.handlers.frame_change_post:
        bpy.app.handlers.frame_change_post.remove(_gheb_frame_change_post)

    if hasattr(bpy.types.Scene, "gheb_props"):
        del bpy.types.Scene.gheb_props

    for cls in reversed(_CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass
